#!/usr/bin/python2
# coding=utf-8
"""
计算句子相似度的方式找答案中的槽点
"""
from __future__ import print_function
from __future__ import division
from codecs import open
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer as TFIDF
from sklearn.metrics.pairwise import pairwise_distances
import jieba, datetime, random
import numpy as np
import csv, sys


csv.field_size_limit(sys.maxsize)


def deal_long_than_140(content):
	"""
	不能用单句的结束标点分割开的答案
	处理为单句保证不会超过140字
	"""
	sentences = []
	first = last = 0
	length = len(content)
	sen_count = int(length / 140)
	for j in range(1, sen_count + 1):
		last = 140 * j-1
		for i in range(last, first, -1):
			if content[i] == '，' or content[i] == ' ':
				sen = content[first:i]
				first = i + 1
				sentences.append(sen)
				break
	return sentences


def split_answer_sentences(content):
	"""分句,单句长度不超过140字(微博长度)，防止没有标点符号或一个逗号到底的情况"""
	first = last = 0
	sentences = []
	for i in range(len(content)):
		if content[i] == '。' or content[i] == '！' or content[i] == '？':
			last = i + 1
			sent = content[first:last]
			if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
				sent = sent.split('……')
				sentences += sent
				first = last
	if first < len(content):
		sent = content[first:]
		if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
			sent = sent.split('……')
			sentences += sent
	sentences_ls = []
	for sen in sentences:
		if len(sen) > 140:
			sentences_ls += deal_long_than_140(sen)
		else:
			sentences_ls.append(sen)
	return sentences_ls


def split_comment_sentences(content):
	"""分句,单句长度不超过140字(微博长度)，防止没有标点符号或一个逗号到底的情况"""
	first = last = 0
	sentences = []
	for i in range(len(content)):
		if content[i] == '。' or content[i] == '！' or content[i] == '？':
			last = i+1
			sent = content[first:last]
			if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
				sentences.append(sent)
				first = last
	if first < len(content):
		sent = content[first:]
		if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
			sentences.append(sent)
	return sentences


def write_sample_score(data, filepath, sample_num):
	'''
	相似性得分区间内的数据里随机出一定数量的数据写入文件，用于分析
	:param data:
	:param filepath:
	:return:
	'''
	score = [i/20 for i in range(20, -1, -1)]
	data_in_score = [[] for i in range(20)]
	data_len = len(data)
	for i in range(0, data_len):
		for j in range(len(score)-1):
			if score[j] > data[i][-1] >= score[j+1]:
				data_in_score[j].append(data[i])
	with open(filepath, "w") as tarfile:
		csv_writer = csv.writer(tarfile, delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\')
		csv_writer.writerow(["id", "content", "predict", "score"])
		for i in range(9, len(data_in_score)):
			every_score_data = data_in_score[i]
			random.shuffle(every_score_data)
			every_score_data = every_score_data[:sample_num]
			for item in every_score_data:
				assert len(item) == 11
				# print(i, item[10])
				csv_writer.writerow([item[4], item[5], '', ''])
				csv_writer.writerow([item[2], item[3].replace(',', '，'), '', ''])
				csv_writer.writerow([item[0], item[1], '', ''])
				csv_writer.writerow([item[6], item[7].replace(',', '，'), item[9].replace(',', '，'), item[10]])
				csv_writer.writerow(['', '', '', ''])
			csv_writer.writerow(['', '', '', ''])
			# return
	print("write sample score Done")


def write_by_score_order(data, filepath, reverse=True):
	"""
	相似性得分排序写入文件
	:param data:
	:param filepath:
	:return:
	"""

	def score_analysis(data, reverse=True):
		'''得分情况统计'''
		x = [i/20 for i in range(20, -1, -1)]
		y = [0]*20
		if not reverse: data.reverse()
		data_len = len(data)
		for i in range(0, data_len):
			for j in range(len(x) - 1):
				if x[j] > data[i] >= x[j + 1]:
					y[j] += 1
		print(y)
		print([round(i / data_len, 4) for i in y])
		print(data_len)
	data = sorted(data, key=lambda x: x[-1], reverse=reverse)
	score_data = []
	with open(filepath, "w") as tarfile:
		csv_writer = csv.writer(tarfile, delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\')
		csv_writer.writerow(["id", "content", "score"])
		for item in data:
			assert len(item) == 11
			csv_writer.writerow([item[4], item[5], '', ''])
			csv_writer.writerow([item[2], item[3], '', ''])
			csv_writer.writerow([item[0], item[1], '', ''])
			csv_writer.writerow([item[6], item[7].replace(',', '，')])
			csv_writer.writerow([item[8], item[9].replace(',', '，'), item[10]])
			csv_writer.writerow(['', '', '', ''])
			score_data.append(item[10])
	print("write to file by score order done")
	score_analysis(score_data, reverse)
	print("score analysis done")


def write_to_file_no_score(data, filepath):
	comment_idset = set()
	answer_dict = {}
	for item in data:
		if item[0] in comment_idset: continue
		comment_idset.add(item[0])
		if item[2] not in answer_dict.keys():
			answer_dict[item[2]] = [item[4], item[5].replace(',', '，'), item[2], item[3].replace(',', '，'),
									[[item[0], item[1].replace(',', '，')]]]
		else:
			answer_dict[item[2]][-1].append([item[0], item[1].replace(',', '，')])
	with open(filepath, 'w') as wfile:
		csv_writer = csv.writer(wfile, delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\')
		csv_writer.writerow(["id", "content"])
		for key, value in answer_dict.items():
			csv_writer.writerow([value[0], value[1]])
			csv_writer.writerow([value[2], value[3]])
			for cid, con in value[-1]:
				csv_writer.writerow([cid, con])
			csv_writer.writerow(['', ''])
	print(len(comment_idset))
	print("Done")


def write_to_file(filepath, data, threshold, reverse=True):
	'''
	得分阈值筛选结果写入文件
	:param filepath:
	:return:
	'''
	count = 0
	with open(filepath, "w") as wfile:
		csv_writer = csv.writer(wfile, delimiter='\t', escapechar='\\', quoting=csv.QUOTE_NONE)
		csv_writer.writerow(['comment_id', 'comment', 'answer_id', 'answer', 'question_id', 'question',
							'comment_order', 'comment_sen', 'answer_order', 'answer_sen', 'score'])
		for sample in data:
			if reverse:
				if sample[-1] > threshold:
					csv_writer.writerow(sample)
					count += 1
			else:
				if sample[-1] <= threshold:
					csv_writer.writerow(sample)
					count += 1
	x = "高于" if reverse else "不高于"
	print(x+"阈值{}的有{}条".format(threshold, count))


def base_word_overlap_similarity(filepath, option, base_words=True):
	"""
	基于词(字)重叠的句子相似度
	:return:
	"""
	def metric_f1(prediction, groud_truth):
		'''
		get precision, recall, f1
		:param prediction: list
		:param groud_truth: list
		:return: p, r, f1
		'''
		comm = Counter(prediction)&Counter(groud_truth)
		num_same = sum(comm.values())
		if num_same == 0: return 0, 0, 0
		p = num_same/len(prediction)
		r = num_same/len(groud_truth)
		f1 = (2*p*r)/(p+r)
		return p, r, f1

	file_suffix = "_word_overlap.csv" if base_words else "_char_overlap.csv"
	with open(filepath, "r") as rfile, open("../user_focus_answer/sen_similarity/sample/one_sen_answer_comment.csv", 'w')\
			as one_file, open("../user_focus_answer/sen_similarity/sample/short_answer_comment.csv", 'w') as short_file:
		csv_reader = csv.reader(rfile, delimiter='\t', quoting=csv.QUOTE_NONE)
		one_csv_writer = csv.writer(one_file, delimiter='\t', escapechar='\\', quoting=csv.QUOTE_NONE)
		short_csv_writer = csv.writer(short_file, delimiter='\t', escapechar='\\', quoting=csv.QUOTE_NONE)
		one_csv_writer.writerow(['comment_id', 'comment', 'answer_id', 'answer', 'question_id', 'question'])
		short_csv_writer.writerow(['comment_id', 'comment', 'answer_id', 'answer', 'question_id', 'question'])
		data_score_order = []
		pre_in_answer_sen = [1, 2, 3]
		pre_in_answer_sen_ratio = [0, 0, 0]
		pre_content_length, comment_length = 0, 0
		one_answer_count, short_answer_count = 0, 0
		for lid, line in enumerate(csv_reader):
			if lid == 0:
				continue
			if lid%100000 == 0: print(lid, datetime.datetime.now())
			comment = line[1]
			answer = line[3]
			sample = line
			comment_sentences = split_comment_sentences(comment)
			answer_sentences = split_answer_sentences(answer)
			answer_sen_count = len(answer_sentences)
			if answer_sen_count == 1: # 单句答案情况
				one_csv_writer.writerow(line)
				one_answer_count += 1
				continue
			if answer_sen_count <= 3:
				# 短答案的情况
				short_csv_writer.writerow(line)
				short_answer_count += 1
				continue
			for c_order, c_sen in enumerate(comment_sentences):
				max_c_metric = [0, '', -1]
				for a_id, ans_sen in enumerate(answer_sentences):
					if base_words:
						c_sen_tokens = jieba.lcut(c_sen)
						a_sen_tokens = jieba.lcut(ans_sen)
					else:
						c_sen_tokens = [item for item in c_sen]
						a_sen_tokens = [item for item in ans_sen]
					c_metric = metric_f1(a_sen_tokens, c_sen_tokens)[-1] # f1
					if c_metric > max_c_metric[0]:
						max_c_metric = [c_metric, ans_sen, a_id]
				for i in pre_in_answer_sen:
					if i - 1 < len(answer_sentences) and i - 1 == max_c_metric[-1]:
						pre_in_answer_sen_ratio[i - 1] += 1
				if max_c_metric[0] == 0: continue
				pre_content_length += len(max_c_metric[1])
				comment_length += len(c_sen)
				sample_data = sample + [c_order, c_sen, max_c_metric[-1], max_c_metric[1], max_c_metric[0]]
				data_score_order.append(sample_data)
	print(option)
	print("单句答案对应的评论数目:{} 短答案(<=3)数目：{}".format(one_answer_count, short_answer_count))
	item_count = len(data_score_order)
	print("数据条数：{} 预测的答案内容平均长度：{} 评论句平均长度：{}".format(item_count,
			pre_content_length / item_count, comment_length / item_count))
	print("预测结果在答案前三句的数目和比例{} {}".format(pre_in_answer_sen_ratio,
			[item / item_count for item in pre_in_answer_sen_ratio]))
	# write_sample_score(data_score_order, '../user_focus_answer/sen_similarity/sample/summar_comment'+file_suffix, 10)
	# write_by_score_order(data_score_order, '../user_focus_answer/sen_similarity/sample/zhihu_sample'+file_suffix, False)
	# write_to_file('../dataset/specific_com/'+option+file_suffix, data_score_order, 0.55)
	# write_to_file('../dataset/extend_com/'+option+file_suffix, data_score_order, 0.55, reverse=False)
	data_ = [item for item in data_score_order if item[-1] <= 0.55]
	# write_by_score_order(data_, '../dataset/extend_com/zhihu_'+option+file_suffix)
	write_to_file_no_score(data_, "../dataset/extend_com/zhihu_sample_extend_comment.csv")
	print("base word overlap done")
	# return data_score_order


def base_tfidf_similarity(filepath):
	"""
	基于Tf-idf矩阵的余弦距离相似度
	:return:
	"""
	with open(filepath, "r") as rfile:
		csv_reader = csv.reader(rfile, delimiter='\t', quoting=csv.QUOTE_NONE)
		data_score_order = []
		pre_in_answer_sen = [1, 2, 3]
		pre_in_answer_sen_ratio = [0, 0, 0]
		pre_content_length, comment_length = 0, 0
		for lid, line in enumerate(csv_reader):
			if lid == 0:
				continue
			comment = line[1]
			answer = line[3]
			sample = [line[4], line[5], line[2], answer.replace(',', '，'), line[0], comment.replace(',', '，')]
			comment_sentences = split_comment_sentences(comment)
			answer_sentences = split_answer_sentences(answer)
			answer_doc = [" ".join(jieba.lcut(sen)) for sen in answer_sentences]
			tfidf = TFIDF(min_df=1, max_features=50, ngram_range=(1, 3), use_idf=1, smooth_idf=1)
			tfidf.fit(answer_doc)
			for c_order, c_sen in enumerate(comment_sentences):
				max_cosine_score = [0, '', -1]
				c_sen_token = " ".join(jieba.lcut(c_sen))
				c_vec = tfidf.transform([c_sen_token])
				for a_id, a_sen in enumerate(answer_doc):
					a_vec = tfidf.transform([a_sen])
					cosine_score = 1-pairwise_distances(c_vec, a_vec, metric="cosine").ravel()[0]
					if cosine_score > max_cosine_score[0]:
						max_cosine_score = [cosine_score, answer_sentences[a_id], a_id]
				for i in pre_in_answer_sen:
					if i-1 < len(answer_sentences) and i-1 == max_cosine_score[-1]:
						pre_in_answer_sen_ratio[i-1] += 1
				pre_content_length += len(max_cosine_score[1])
				comment_length += len(c_sen)
				sample_data = sample + [c_order, c_sen.replace(',', '，'), max_cosine_score[1].replace(',', '，'), max_cosine_score[0]]
				data_score_order.append(sample_data)
	item_count = len(data_score_order)
	print("数据条数：{} 预测的答案内容平均长度：{} 评论句平均长度：{}".format(item_count,
					pre_content_length / item_count, comment_length / item_count))
	print("预测结果在答案前三句的数目和比例{} {}".format(pre_in_answer_sen_ratio,
					[item / item_count for item in pre_in_answer_sen_ratio]))
	write_by_score_order(data_score_order, '../user_focus_answer/sen_similarity/zhihu_sample_tfidf.csv')
	print("base tfidf similarity done")


def base_edit_distance_similarity(filepath):
	"""
	基于答案句与评论句之间的编辑距离
	:param filepath:
	:return:
	"""
	def edit_distance(pre_str, groud_str):
		pre_len, groud_len = len(pre_str), len(groud_str)
		matrix = [[i+j for j in range(groud_len+1)] for i in range(pre_len+1)]
		for i in range(1, pre_len+1):
			for j in range(1, groud_len+1):
				if pre_str[i-1] == groud_str[j-1]:
					d = 0
				else:
					d = 1
				matrix[i][j] = min(matrix[i-1][j]+1, matrix[i][j-1]+1, matrix[i-1][j-1]+d)
		return matrix[pre_len][groud_len]

	with open(filepath, "r") as rfile:
		csv_reader = csv.reader(rfile, delimiter='\t', quoting=csv.QUOTE_NONE)
		data_score_order = []
		pre_in_answer_sen = [1, 2, 3]
		pre_in_answer_sen_ratio = [0, 0, 0]
		pre_content_length, comment_length = 0, 0
		for lid, line in enumerate(csv_reader):
			if lid == 0:
				continue
			if lid%10000==0: print(lid, datetime.datetime.now())
			comment = line[1]
			answer = line[3]
			sample = [line[4], line[5], line[2], answer.replace(',', '，'), line[0], comment.replace(',', '，')]
			comment_sentences = split_comment_sentences(comment)
			answer_sentences = split_answer_sentences(answer)
			answer_sen_count = len(answer_sentences)
			for c_order, c_con in enumerate(comment_sentences):
				min_score = [1, '', -1]
				for a_order, a_con in enumerate(answer_sentences):
					if len(c_con) == 0:
						print(a_order, comment, c_con)
					matrix_score = edit_distance(a_con, c_con)/len(c_con)
					if matrix_score < min_score[0]:
						min_score = [matrix_score, a_con, a_order]
				for i in pre_in_answer_sen:
					if i-1 < answer_sen_count and i-1 == min_score[-1]:
						pre_in_answer_sen_ratio[i-1] += 1
				pre_content_length += len(min_score[1])
				comment_length += len(c_con)
				sample_data = sample + [c_order, c_con, min_score[1].replace(',', '，'), min_score[0]]
				data_score_order.append(sample_data)
		item_count = len(data_score_order)
		print("数据条数：{} 预测的答案内容平均长度：{} 评论句平均长度：{}".format(item_count,
				pre_content_length / item_count, comment_length / item_count))
		print("预测结果在答案前三句的数目和比例{} {}".format(pre_in_answer_sen_ratio,
				[item / item_count for item in pre_in_answer_sen_ratio]))
		# write_by_score_order(data_score_order, '../user_focus_answer/sen_similarity/zhihu_sample_edit_distance.csv', False)
		print("edit distance similarity done")
		return data_score_order


def intersection(data2, data3):
	'''
	三个筛选后的结果
	:return:
	'''
	# data1_dict = {item[4]+"_"+str(item[-4]): [item[-2], item[-1]] for item in data1 if item[-1] > 0.5}  # c_id+'_'+c_order : score
	data2_dict = {item[4]+"_"+str(item[-4]): [item[-2], item[-1]] for item in data2 if item[-1] > 0.55}
	data3_dict = {item[4]+"_"+str(item[-4]): [item[-2], item[-1]] for item in data3 if item[-1] < 0.7}
	# data1_set = set(data1_dict.keys())
	data2_set = set(data2_dict.keys())
	data3_set = set(data3_dict.keys())
	data2_len, data3_len = len(data2_set), len(data3_set)
	print(data2_len, data3_len) # 三个筛选的大小
	# data1_and_data2 = data1_set & data2_set
	# data1_and_data3 = data1_set & data3_set
	data2_and_data3 = data2_set & data3_set
	print(len(data2_and_data3))
	# data1_and_data2_and_data3 = data1_set & data2_set & data3_set
	# print("data1 & data2: {} \n data1 & data3: {} \n data2 & data3: {} \n data1 & data2 & data3:{}".format(len(data1_and_data2),
			# len(data1_and_data3), len(data2_and_data3), len(data1_and_data2_and_data3)))
	print("write intersection to file")
	with open("../user_focus_answer/sen_similarity/zhihu_all_intersection_0.5_0.4_0.7.csv", 'w') as wfile:
		csv_writer = csv.writer(wfile, delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\')
		csv_writer.writerow(['id', 'content', 'predict', 'score1', 'score2', 'score3'])
		for item in data2:
			item_key = item[4]+"_"+str(item[-4])
			if item_key in data2_and_data3:
				csv_writer.writerow([item[0], item[1], '', '', '', ''])
				csv_writer.writerow([item[2], item[3], '', '', '', ''])
				csv_writer.writerow([item[4], item[5], '', '', '', ''])
				csv_writer.writerow([item[6], item[7], item[8], item[9], data2_dict[item_key][1], data3_dict[item_key][1]])
				# csv_writer.writerow([item[6], 'char_overlap', data2_dict[item_key][0], ])
				# csv_writer.writerow([item[6], 'edit_dis', data3_dict[item_key][0], ])
				csv_writer.writerow(['', '', '', ''])
	print("write done")


def main():
	sample_file = "../data/data/comment/sample/zhihu_sample_fix.csv"
	all_data = "../dataset/dataset/all_dataset.csv"
	# word_set = base_word_overlap_similarity(sample_file)
	train_file = "../dataset/dataset/trainset.csv"
	testset1_file = "../dataset/dataset/testset1.csv"
	testset2_file = "../dataset/dataset/testset2.csv"
	validset1_file = "../dataset/dataset/validset1.csv"
	validset2_file = "../dataset/dataset/validset2.csv"
	base_word_overlap_similarity(sample_file, 'sample', False)
	# base_word_overlap_similarity(testset1_file, 'testset1', False)
	# base_word_overlap_similarity(testset2_file, 'testset2', False)
	# base_word_overlap_similarity(validset1_file, 'validset1', False)
	# base_word_overlap_similarity(validset2_file, 'validset2', False)

	# data2_dict = {item[4] + "_" + str(item[-4]): [item[-2], item[-1]] for item in char_set if item[-1] > 0.55}
	# print(len(data2_dict))
	# base_tfidf_similarity(sample_file)
	# edit_set = base_edit_distance_similarity(sample_file)
	# intersection(char_set, edit_set)


if __name__ == '__main__':
	main()