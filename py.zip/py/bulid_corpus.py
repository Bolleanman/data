#!/usr/bin/python2
# coding=utf-8
"""
转为翻译预料数据形式
"""
from __future__ import print_function
from __future__ import division
from codecs import open
import csv, sys
csv.field_size_limit(sys.maxsize)


def trans_to_mt(filepath, tarfile):
	with open(filepath, "r") as srcfile:
		with open(tarfile+".com", 'w') as comfile, open(tarfile+".ans", 'w') as ansfile, open(tarfile+".cid", 'w') as cidfile:
			csv_reader = csv.reader(srcfile, delimiter='\t', quoting=csv.QUOTE_NONE)
			for lid, line in enumerate(csv_reader):
				if lid == 0: print(line); continue
				comfile.write(line[7]+"\n")
				ansfile.write(line[9]+"\n")
				cidfile.write(line[0]+"\t"+str(line[6])+"\t"+str(line[8])+"\n")  # cid corder aorder
	print("{} Done".format(filepath))


def main():
	train_src_file = "../dataset/specific_com/train_char_overlap.csv"
	test1_src_file = "../dataset/specific_com/testset1_char_overlap.csv"
	test2_src_file = "../dataset/specific_com/testset2_char_overlap.csv"
	valid1_src_file = "../dataset/specific_com/validset1_char_overlap.csv"
	valid2_src_file = "../dataset/specific_com/validset2_char_overlap.csv"

	train_tar_file = "../dataset/corpus/train"
	test1_tar_file = "../dataset/corpus/testset1"
	test2_tar_file = "../dataset/corpus/testset2"
	valid1_tar_file = "../dataset/corpus/validset1"
	valid2_tar_file = "../dataset/corpus/validset2"

	trans_to_mt(train_src_file, train_tar_file)
	trans_to_mt(test1_src_file, test1_tar_file)
	trans_to_mt(test2_src_file, test2_tar_file)
	trans_to_mt(valid1_src_file, valid1_tar_file)
	trans_to_mt(valid2_src_file, valid2_tar_file)


if __name__ == '__main__':
	main()
