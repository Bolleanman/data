#!/usr/bin/python2
# coding=utf-8
import json
import pickle
import csv
import jieba
import sys, time, math
import datetime
csv.field_size_limit(sys.maxsize)



def read_data(filepath):
	"""
	评论内容的统计分析
	1.万能评论的筛选(根据评论出现的频率，较高频率的评论作为万能评论)
	2.评论分词的情况，分词后评论的次数统计，词频统计
	:param filepath:
	:return:
	"""
	com_dict = dict()
	word_dict = dict()
	comment_len = []
	# row_name = []
	start_t = time.time()
	with open(filepath) as csv_file:
		csv_reader = csv.reader(csv_file, delimiter='\t', quoting=csv.QUOTE_NONE)
		for lid, line in enumerate(csv_reader):
			if lid == 0:
				# row_name = line
				continue
			if len(line) != 0:
				content = line[0]
				seg_content = jieba.lcut(content)
				comment_len.append(len(seg_content))
				if content in com_dict:
					com_dict[content] += 1
				else:
					com_dict[content] = 1
				for word in seg_content:
					if word in word_dict:
						word_dict[word] += 1
					else:
						word_dict[word] = 1
			if lid % 1000000 == 0:
				f_time = time.time()
				print(lid, f_time-start_t)
				start_t = f_time
	with open("comment_words.pkl", "wb") as f:
		pickle.dump(comment_len, f)
	with open("log.log","w") as logf:
		logf.write("评论总数:{} \n".format(lid))
		# print("平均词数：", sum(comment_len)/len(comment_len))
		logf.write("平均次数:{} \n".format(sum(comment_len)/len(comment_len)))
		# print("非重复评论数:", len(com_dict), "词表大小：", len(word_dict))
		logf.write("非重复评论数目:{} 词表大小:{} \n".format(len(com_dict), len(word_dict)))
		threshold = 10
		w_threshold = 50
		n_com_dict, n_word_dict = dict(), dict()
		for key, value in com_dict.items():
			if value >= threshold:
				n_com_dict[key] = value
		for key, value in word_dict.items():
			if value >= w_threshold:
				n_word_dict[key] = value
		# print("阈值为{}时".format(threshold), "非重复评论数:", len(n_com_dict), "词表大小:", len(n_word_dict))
		logf.write("评论阈值设置{}时，非重复评论数{}， 词表阈值设置{}时， 词表大小{} \n".format(threshold, len(n_com_dict), w_threshold, len(n_word_dict)))
		n_com_dict = sorted(n_com_dict.items(), key=lambda x: x[1], reverse=True)
		n_word_dict = sorted(n_word_dict.items(), key=lambda x: x[1], reverse=True)
		unique_com_path = "../data/data/comment/unique_comment.txt"
		logf.write("write unique comment in {} \n".format(unique_com_path))
		with open(unique_com_path, "w", encoding="utf-8") as com_file:
			for item, freq in n_com_dict:
				com_file.write("{} \t{}\n".format(item, freq))
		vocab_path = "../data/data/comment/vocab.txt"
		logf.write("write vocab in {} \n".format(vocab_path))
		with open(vocab_path, "w", encoding="utf-8") as word_file:
			for item, freq in n_word_dict:
				word_file.write("{} \t {} \n".format(item, freq))
		logf.write("finish at {}".format(datetime.datetime.now()))


# read_data("../data/data/comment/comment.csv")



def comment_time(filepath):
	"""
	答案下评论创建时间的统计：
	1.答案创建与第一条评论的时间间隔统计（评论创建时间的排序，计算第一条评论的时间与答案时间差）
	2.评论与评论的时间间隔统计 （计算排好后后评论之间的时间差，统计时间差与评论数目的关系，是否可以说明，评论会吸引更多的评论）
	3.评论互相回复的时间间隔统计 （发表评论后，对其回复中间的时间间隔，是否可以说明，评论可以获得回复的情况）
	根据统计结果说明早期的评论是否可以解决冷启动的问题
	# 数据格式
	answer_id, created_time,[comment_id], [created_time], [reply_comment_id], [upvoted_num]
	:param filepath: filepath
	:return:
	"""
	rowname = []
	data_samples = []
	with open(filepath) as csv_file:
		with open(filepath.split(".csv")[0]+".json", "w", encoding="utf-8") as jsf:
			csv_reader = csv.reader(csv_file, delimiter="\t", quoting=csv.QUOTE_NONE)
			for lid, line in enumerate(csv_reader):
				if lid == 0:
					rowname = line
					continue
				answer_id = line[0]
				answer_time = line[1]
				comments = []
				str2list = lambda x: [int(x) for x in (x.strip("[").strip("]")).split(",")] # "[123,456,789]" > [123, 456, 789]
				comment_id_ls, comment_time_ls = str2list(line[2]), str2list(line[3])
				comment_reple_id_ls, comment_upvoted_ls = str2list(line[4]), str2list(line[5])
				for i in range(len(comment_id_ls)):
					comments.append([comment_id_ls[i], comment_time_ls[i], comment_reple_id_ls[i], comment_upvoted_ls[i]])
				comments = sorted(comments, key=lambda x: x[1], reverse=False)
				answer_time = datetime.datetime.fromtimestamp(int(answer_time))
				first_time_space = (datetime.datetime.fromtimestamp(int(comments[0][1]))-answer_time).total_seconds()
				comment_time_space = []
				print(comments[0])
				if len(comments) > 1:
					for i in range(1, len(comments)):
						time_space = (datetime.datetime.fromtimestamp(int(comments[i][1])) - datetime.datetime.fromtimestamp(int(comments[i-1][1]))).total_seconds()
						comment_time_space.append(time_space)
				sample = dict()
				sample[answer_id] = [int(line[1]), first_time_space, comments, comment_time_space]
				if len(data_samples) == 0: print(sample)
				data_samples.append(sample)
			jsf.write(json.dumps(data_samples, ensure_ascii=False))
	print("Finish")


def run_command(comment_time_path):
	import os
	read = os.popen("hive -f {} > {}".format("../data/data/comment/comment_time.sql", comment_time_path))
	# comment_time("../data/data/comment/comment_time.csv")
	print(read.read())

#
# comment_time_path = "../data/data/comment/comment_time.csv"
#
# run_command(comment_time_path)
# comment_time(comment_time_path)



def numls_static(numls, option):
	"""
	计算均值、方差、最值、众数、中数
	:param numls: 评论的词数 list
	:return:
	"""
	with open(option+".log", "w", encoding="utf-8") as f:
		f.write("{} 分析结果\n".format(option))
		min_x, max_x = 1e5, -1
		avg_x = sum(numls)/len(numls)
		sigma = 0
		num_freq = dict()
		for x in numls:
			if x > max_x: max_x = x
			if x < min_x: min_x = x
			sigma += (x-avg_x)**2
			if x in num_freq:
				num_freq[x] += 1
			else:
				num_freq[x] = 1
		num_ls = sorted(numls)
		mid_num = num_ls[int(len(num_ls)/2)]
		max_index = max(num_freq, key=num_freq.get)
		most_num = max_index
		sigma = math.sqrt(sigma)
		f.write("均值:{} \n方差:{} \n最大值:{} \n最小值:{} \n中数：{} \n众数:{}".format(avg_x,
				sigma, max_x, min_x, mid_num, most_num))
		num_freqls = sorted(num_freq.items(), key=lambda x:x[0], reverse=False)
		# sum_ratio = 0
		# f.write("值\t数目\t频率\t不大于的所占总频率\n")
		# for i in range(50):
		# 	ratio = num_freqls[i][1]/len(numls)
		# 	sum_ratio += ratio
		# 	f.write("{}\t{}\t{}\t{}\n".format(num_freqls[i][0], num_freqls[i][1], ratio, sum_ratio))
		with open("{}.pkl".format(option), "wb") as f:
			pickle.dump(num_freqls, f)


def read_comment_words():
	filepath = "comment_words.pkl"
	with open(filepath, "rb") as f:
		return pickle.load(f)


# 评论的词数
# numls_static(read_comment_words(), "comment_words")


def vocab_remove_stopwords(vocab_file, stopwords_file):
	"""
	分词的词表中去除停用词（停用词表:哈工大停用词表 百度停用词表）
	:param vocab_file:
	:param stopwords_file:
	:return:
	"""
	def get_stopwords(stopwords_file):
		stopwords = list()
		with open(stopwords_file, "r", encoding="utf-8") as f:
			for line in f.read():
				line = line.strip('\n')
				if len(line) == 0: continue
				stopwords.append(line.strip('\n'))
		print(len(stopwords))
		return stopwords
	hit_stopwords = get_stopwords("../data/data/comment/hit_stopwords.txt")
	baidu_stopwords = get_stopwords("../data/data/comment/baidu_stopwords.txt")
	with open(vocab_file, "r", encoding="utf-8") as vf:
		with open(vocab_file.split(".txt")[0]+"_stpw.txt", "w", encoding="utf-8") as vsf:
			for lid, line in enumerate(vf):
				item = line.strip("\n").split("\t")[0]
				item = item.strip(' ')
				if item not in hit_stopwords and item not in baidu_stopwords:
					vsf.write(line)
	print("Done!")


def repeat_comment(filepath):
	with open(filepath, "r") as f:
		nums = 0
		for line in f:
			nums += int((line.strip("\n")).split('\t')[1])
	print(nums)


# repeat_comment("../data/data/comment/unique_comment.txt")



# vocab_remove_stopwords("../data/data/comment/vocab.txt", "../data/data/comment/baidu_stopwords.txt")

def get_first_time_space():
	"""
	答案与第一条评论的时间间隔的统计
	:return:
	"""
	filepath = "../data/data/comment/comment_time.json"
	with open(filepath, "r", encoding="utf-8") as f:
		samples = json.loads(f.read())
		first_time_ls = []
		for sample in samples:
			for key, val in sample.items():
				first_time_ls.append(val[1])
		numls_static(first_time_ls, "first_time_space")

def get_first_time_comment_num():
	"""
	第一条评论时间间隔与评论数量间的关系
	:return:
	"""
	filepath = "../data/data/comment/comment_time.json"
	with open(filepath, "r", encoding="utf-8") as f:
		samples = json.loads(f.read())
		data = []
		for sample in samples:
			for key, value in sample.items():
				data.append([value[1], len(value[-1])+1])
		with open("comment_time_num.pkl", "wb") as cf:
			pickle.dump(data, cf)
# 最早评论与答案的时间间隔
# get_first_time_space()
# 首条评论时间间隔与答案下评论的数目
# get_first_time_comment_num()


# 评论赞数以及评论的时间的关系//同一答案下的评论，是否是越早的评论获得的赞数就越多
def comment_time_upvote():
	"""
	同一答案的评论时间与评论的赞数
	:return:
	"""
	file_path = "../data/data/comment/comment_time.json"
	with open(file_path, "r", encoding="utf-8") as f:
		samples = json.loads(f.read())
		datas = []
		for sample in samples:
			for key, value in sample.items():
				comment = value[2]
				if len(comment) > 500:
					comment = sorted(comment, key=lambda x: x[1], reverse=False)
					datas.append(comment)
	print(len(datas))
	with open("time_upvote.pkl", "wb") as fv:
		pickle.dump(datas, fv)

		
comment_time_upvote()


