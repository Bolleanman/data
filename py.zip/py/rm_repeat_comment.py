#!/usr/bin/python2
# coding=utf-8
from __future__ import print_function
from __future__ import division
from codecs import open
import csv, sys
import json
import datetime

csv.field_size_limit(sys.maxsize)



def read_repeat_data(filepath):
	#read repeat data
	with open(filepath) as f:
		repeat_comment = dict()
		for line in f.read():
			comment = line.split("\t")[0]
			repeat_comment[comment] = 0
	return repeat_comment


def read_good_comment(filepath, repeat_comment):
	# remove repeat comment
	c_id_set = set()
	c_re_count = 0
	c_count = 0
	samples = []
	r_count = 0
	print("start...")
	with open(filepath) as f:
		csv_reader = csv.reader(f, delimiter='\t', quoting=csv.QUOTE_NONE)
		with open(filepath.split(".csv")[0]+"_unique.csv", "w") as wf:
			csv_writer = csv.writer(wf, delimiter='\t', quoting=csv.QUOTE_NONE, escapechar ='\\')
			csv_writer.writerow(["comment_id", "comment_content", "answer_id", "answer_content", "question_id", "question_title"])
			for lid, line in enumerate(csv_reader):
				if lid == 0: continue
				# if lid == 1: print(len(line), type(line), line[0])
				c_id, c_content = line[0], line[1]
				a_id, a_content = line[2], line[3]
				q_id, q_content = line[4], line[5]
				if lid%200000 == 0:
					# wf.write(json.dumps(samples, ensure_ascii=True))
					csv_writer.writerows(samples)
					r_count += len(samples)
					samples = []
					print("lid", lid, datetime.datetime.now())
				if c_id in c_id_set:
					c_re_count += 1
					continue
				c_count = lid+1
				c_id_set.add(c_id)
				if c_content in repeat_comment.keys():
					repeat_comment[c_content] += 1
					continue
				samples.append([c_id, c_content, a_id, a_content, q_id, q_content])
			csv_writer.writerows(samples)
			print("重复评论id", c_re_count, c_re_count/c_count)
			r_count = len(samples)+r_count
			print("去重后评论量:", r_count, r_count/c_count)
			# repeat comment in good comment
			repeat_comment = sorted(repeat_comment.items(), key=lambda x:x[1], reverse=True)
			with open("rm_unique_log.txt", "w") as uf:
				uf.write("重复评论id{} {}\n".format(c_re_count, c_re_count/c_count))
				uf.write("去重后评论量:{} {}\n".format(r_count, r_count/c_count))
				for key, value in repeat_comment:
					if value > 0:
						uf.write(key+"\t"+str(value)+"\n")
			print("Done!")


def main():
	repeat_comment = read_repeat_data("../data/data/comment/unique_comment.txt")
	read_good_comment("../data/data/comment/good_comment.csv", repeat_comment)


if __name__=="__main__":
	main()
