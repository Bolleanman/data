#!/usr/bin/python2
# coding=utf-8
"""
数据内容分析
人工对评论进行分析
评论内容分类
"""
from __future__ import print_function
from __future__ import division
from codecs import open
import csv, sys, pickle


csv.field_size_limit(sys.maxsize)


def write_to_file(filepath, name, data):
	with open(filepath, "w") as f:
		csv_writer = csv.writer(f, delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\')
		csv_writer.writerow(name)
		for item in data:
			csv_writer.writerow([item[2], item[3]])
			csv_writer.writerow([item[0], item[1]])
			comments = item[-1]
			for c_id, c_con in comments:
				csv_writer.writerow([c_id, c_con])
			# 一个问答对
			csv_writer.writerow([" ", " "]) # 问答对之间空行
	print("Write to {} done".format(filepath))


def get_sample_Data(filepath):
	"""
	从总数据中选择10388（>=9的问答对）对应的评论，分析这些
	:param filepath:
	:return:
	"""
	pair_qa = dict()
	with open(filepath, "r") as file:
		csv_reader = csv.reader(file, delimiter='\t', quoting=csv.QUOTE_NONE)
		for lid, line in enumerate(csv_reader):
			if lid == 0:
				print(line)
				assert len(line) == 7
				continue
			answer_id = line[3]
			if answer_id not in pair_qa:
				# [answer qid question [cid, comment]]
				pair_qa[answer_id] = [line[-3], line[-2], line[-1], [[line[0], line[1]]]]
			else:
				pair_qa[answer_id][-1].append([line[0], line[1]])
	print("qa_pair_num {}".format(len(pair_qa)))
	# 抽取采样的数据 评论>=9的问答对10388
	c_num_qa_pair = dict()
	for key, value in pair_qa.items():
		comment_num = len(value[-1])
		if comment_num < 9: continue
		if comment_num not in c_num_qa_pair:
			c_num_qa_pair[comment_num] = [[key]+value]
		else:
			c_num_qa_pair[comment_num].append([key]+value)
	# 抽样2%的数据进行人工查看
	# for key, value in c_num_qa_pair.items():
	# 	qa_pair_num = len(value)
	# 	# sample_num = int(qa_pair_num/10) if qa_pair_num/10 >= 1 else 1
	# 	sample_num = int(qa_pair_num/50)
	# 	if sample_num > 0:
	# 		write_to_file("../sample/sample_"+str(key)+".csv", ["id", "content"], value[:sample_num])
	# 		c_num_qa_pair[key] = value[:sample_num]
	# 	else:
	# 		c_num_qa_pair[key] = []
	# sample data
	answer_id_set = set()
	with open(filepath.split("in_qa_len_filter.csv")[0]+"10388_sample.csv", "w") as wf:
		csv_writer = csv.writer(wf, delimiter='\t', quoting=csv.QUOTE_NONE, escapechar='\\')
		csv_writer.writerow(["comment_id", "comment", "answer_id", "answer", "question_id", "question"])
		comment_count = 0
		for key, value in c_num_qa_pair.items():
			# key comment_num
			for item in value:
				answer_id = item[0]
				if answer_id not in answer_id_set:
					answer_id_set.add(answer_id)
				answer = item[1]
				question_id = item[2]
				question = item[3]
				comments = item[-1]
				for cid, ccon in comments:
					csv_writer.writerow([cid, ccon, answer_id, answer, question_id, question])
					comment_count += 1
	print(len(answer_id_set), comment_count)
	print("Done")


def deal_long_than_140(content):
	"""
	不能用单句的结束标点分割开的答案
	处理为单句保证不会超过140字
	"""
	sentences = []
	first = 0
	length = len(content)
	sen_count = int(length / 140)
	# print(length, sen_count)
	for j in range(1, sen_count + 1):
		last = 140 * j-1
		for i in range(last, first, -1):
			if content[i] == '，' or content[i] == ' ' or content[i] == ',':
				sen = content[first:i]
				first = i + 1
				sentences.append(sen)
				break
	if len(sentences) == 0:
		[sentences.append(content[i:i+140]) for i in range(0, length, 140)]
	return sentences


def split_answer_sentences(content):
	"""分句,单句长度不超过140字(微博长度)，防止没有标点符号或一个逗号到底的情况"""
	first = last = 0
	sentences = []
	for i in range(len(content)):
		if content[i] == '。' or content[i] == '！' or content[i] == '？' or content[i] == '!' or content[i] == '?':
			last = i + 1
			sent = content[first:last]
			if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
				sent = sent.split('……')
				sentences += sent
				first = last
	if first < len(content):
		sent = content[first:]
		if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
			sent = sent.split('……')
			sentences += sent
	sentences_ls = []
	for sen in sentences:
		if len(sen) > 140:
			sentences_ls += deal_long_than_140(sen)
		else:
			sentences_ls.append(sen)
	return sentences_ls


def split_comment_sentences(content):
	"""分句,单句长度不超过140字(微博长度)，防止没有标点符号或一个逗号到底的情况"""
	first = last = 0
	sentences = []
	for i in range(len(content)):
		if content[i] == '。' or content[i] == '！' or content[i]=='!' or content[i] == '？' or content[i] == '?':
			last = i+1
			sent = content[first:last]
			if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
				sent = sent.split('……')
				sentences += sent
				first = last
	if first < len(content):
		sent = content[first:]
		if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
			sent = sent.split('……')
			sentences += sent
	return sentences


def sentence_distribution(filepath):
	"""
	句子数目的分布情况
	答案单句的有多少？
	评论是单句的有多少？
	:return:
	"""
	with open(filepath, "r") as csvfile:
		csv_reader = csv.reader(csvfile, delimiter='\t', quoting=csv.QUOTE_NONE)
		answer_sen_dict, answer_set = {}, set()
		comment_sen_dict = {}
		one_sen_answer_count, short_answer_count = 0, 0
		comment_count = 0
		for lid, line in enumerate(csv_reader):
			if lid == 0: continue
			answer = line[3]
			answer_sen_count = len(split_answer_sentences(answer))
			comment_count = lid + 1
			if answer_sen_count == 1: one_sen_answer_count += 1
			if answer_sen_count <= 3: short_answer_count += 1
		# 	comment = line[1]
		# 	comment_sen_count = len(split_comment_sentences(comment))
		# 	if comment_sen_count not in comment_sen_dict:
		# 		comment_sen_dict[comment_sen_count] = 1
		# 	else:
		# 		comment_sen_dict[comment_sen_count] += 1
		# 	a_id = line[2]
		# 	if a_id not in answer_set:
		# 		answer = line[3]
		# 		answer_sen_count = len(split_answer_sentences(answer))
		# 		if answer_sen_count == 0: print(answer)
		# 		if answer_sen_count not in answer_sen_dict:
		# 			answer_sen_dict[answer_sen_count] = 1
		# 		else:
		# 			answer_sen_dict[answer_sen_count] += 1
		# 		answer_set.add(a_id)
		# answer_sen_list = sorted(answer_sen_dict.items(), key=lambda x: x[0], reverse=False)
		# comment_sen_list = sorted(comment_sen_dict.items(), key=lambda x: x[0], reverse=False)
		# print("{} 统计情况".format(filepath))
		# print("答案句子数统计情况: {}".format(len(answer_set)))
		# print("句子数最多的为: {} -> {}".format(max(answer_sen_dict, key=answer_sen_dict.get), max(answer_sen_dict.values())))
		# for i in range(0, 10):
		# 	print("{}\t{}\t{}".format(answer_sen_list[i][0], answer_sen_list[i][1], round(answer_sen_list[i][1]/len(answer_set),4)))
		# print("评论句子数统计情况:{}".format(comment_count))
		# print("句子数最多为:{} -> {}".format(max(comment_sen_dict, key=comment_sen_dict.get), max(comment_sen_dict.values())))
		# for i in range(0, 10):
		# 	print("{}\t{}\t{}".format(comment_sen_list[i][0], comment_sen_list[i][1], round(comment_sen_list[i][1]/comment_count,4)))
		print(one_sen_answer_count, short_answer_count, comment_count, one_sen_answer_count/comment_count, short_answer_count/comment_count)
		print("Done")




def main():
	# data_file = "../data/data/comment/good_comment_in_qa_len_filter.csv"
	# get_sample_Data(data_file)
	data_sample_all = "../data/data/comment/sample/good_comment_10388_sample_fix.csv"
	data_sample = "../data/data/comment/sample/zhihu_sample_fix.csv"
	testset1 = "../dataset/dataset/testset1.csv"
	testset2 = "../dataset/dataset/testset2.csv"
	trainset = "../dataset/dataset/trainset.csv"
	alldataset = "../dataset/dataset/all_dataset.csv"
	# sentence_distribution(data_sample_all)
	# sentence_distribution(data_sample)
	# sentence_distribution(testset1)
	# sentence_distribution(trainset)
	sentence_distribution(alldataset)

if __name__ == "__main__":
	main()