#!/usr/bin/python2
# coding=utf-8
from __future__ import print_function
from __future__ import division
from codecs import open
import csv
import sys
import json
import jieba
import re


csv.field_size_limit(sys.maxsize)


def answer_filter(content):
	"""
	去除答案中的超链接(图片、视频)
	格式符号<br> <p>等
	:param content:
	:return:
	"""
	img_pattern = r"<img.*?>"
	video_pattern = r"<video.*?<\/video>"
	url_pattern = r"<a.*?href=.*?<\/a>"
	class_pattern = r'<a.*?class=.*?>'
	format_pattern = r'</*[a-z]{1,10}>|>|02<br>'
	patterns = [img_pattern, video_pattern, url_pattern, class_pattern, format_pattern]
	for pattern in patterns:
		content = re.sub(pattern, '', content)
	if len(content) == 0 or len(content.strip(' ')) == 0:
		return None
	return content


def fix_all_data(all_data_file):
	"""
	修复整体数据内容
	:param all_data_file:
	:return:
	"""
	with open(all_data_file, "r") as all_file, open(all_data_file.split(".csv")[0]+"_fix.csv", 'w') as wa_file:
		csv_reader = csv.reader(all_file, delimiter='\t', quoting=csv.QUOTE_NONE)
		csv_writer = csv.writer(wa_file, delimiter='\t', quoting=csv.QUOTE_NONE, escapechar='\\')
		for lid, line in enumerate(csv_reader):
			if lid == 0:
				csv_writer.writerow(line)
				continue
			if lid%200000 == 0: print(lid)
			try:
				ans_id = line[2]
				if ans_id == 'NULL':
					continue
				test_id = re.sub(r'[\d]', '', ans_id)
				if len(test_id) != 0:       # answer_id 对应不上，评论中出现分隔符
					ans_id_index = 0
					for xid, x in enumerate(line[2:-2]):
						test_x = re.sub(r'[\d]', '', x)
						if len(test_x) == 0:
							ans_id_index = xid
							break
					ans_id_index += 1
					comment = line[1:ans_id_index]
					comment = ''.join(comment)
					comment = comment.replace('\t', ' ')
					ans_id = line[ans_id_index]
					answer = ''.join(line[ans_id_index+1:-2])
					ans_content = answer.replace('\t', ' ')
					# 修复整体内容
				else:
					comment = line[1]
					ans_id = line[2]
					ans_content = ''.join(line[3:-2])
					ans_content = ans_content.replace('\t', ' ')
				ans_content = answer_filter(ans_content)
				if ans_content is not None:
					# 写入文件
					csv_writer.writerow([line[0], comment, ans_id, ans_content, line[-2], line[-1]])
			except Exception as e:
				print(len(line))
				print(line)
				raise ValueError('error id')
	# print("answer num :{}".format(len(answer_dict)))
	# return answer_dict
	print("fix all data done")


def read_all_data(datafile):
	comments_data = {}
	with open(datafile, "r") as all_file:
		csv_reader = csv.reader(all_file, delimiter='\t', quoting=csv.QUOTE_NONE)
		for lid, line in enumerate(csv_reader):
			assert len(line) == 6
			if lid == 0: continue
			comment_id = line[0]
			if comment_id not in comments_data:
				comments_data[comment_id] = line[1:]
	print("read all data done")
	return comments_data


def fix_answer_content(all_data, dataset_file):
	"""
	修复答案内容
	修复数据集中答案因去除图片、视频超链接多去除的内容
	"""
	with open(dataset_file, "r") as file, open(dataset_file.split(".csv")[0]+"_fix.csv", "w") as wfile:
		csv_reader = csv.reader(file, delimiter='\t', quoting=csv.QUOTE_NONE)
		csv_writer = csv.writer(wfile, delimiter='\t', quoting=csv.QUOTE_NONE, escapechar='\\')
		not_all_count = 0
		for lid, line in enumerate(csv_reader):
			if lid == 0:
				print(line)
				csv_writer.writerow(line)
				continue
			comment_id = line[0]
			if comment_id in all_data:
				csv_writer.writerow([comment_id]+all_data[comment_id])
			else:
				print("comment_id {} not in all data".format(comment_id))
				print(line)
				not_all_count += 1
				csv_writer.writerow(line)
				# raise ValueError("dataset not in alldata") # wtf?
	print(not_all_count)
	print("{} fix Done".format(dataset_file))


def deal_long_than_140(content):
	"""
	不能用单句的结束标点分割开的答案
	处理为单句保证不会超过140字
	"""
	sentences = []
	first = last = 0
	length = len(content)
	sen_count = int(length / 140)
	for j in range(1, sen_count + 1):
		last = 140 * j
		for i in range(last, first, -1):
			if content[i] == '，' or content[i] == ' ':
				sen = content[first:i]
				first = i + 1
				sentences.append(sen)
				break
	return sentences


def split_answer_sentences(content):
	"""分句,单句长度不超过140字(微博长度)，防止没有标点符号或一个逗号到底的情况"""
	first = last = 0
	sentences = []
	for i in range(len(content)):
		if content[i] == '。' or content[i] == '！' or content[i] == '？':
			last = i + 1
			sent = content[first:last]
			if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
				sent = sent.split('……')
				sentences += sent
				first = last
	if first < len(content):
		sent = content[first:]
		if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
			sent = sent.split('……')
			sentences += sent
	sentences_ls = []
	for sen in sentences:
		if len(sen) > 140:
			sentences_ls += deal_long_than_140(sen)
		else:
			sentences_ls.append(sen)
	return sentences_ls


def split_comment_sentences(content):
	"""分句,单句长度不超过140字(微博长度)，防止没有标点符号或一个逗号到底的情况"""
	first = last = 0
	sentences = []
	for i in range(len(content)):
		if content[i] == '。' or content[i] == '！' or content[i] == '？':
			last = i+1
			sent = content[first:last]
			if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
				sent = sent.split('……')
				sentences += sent
				first = last
	if first < len(content):
		sent = content[first:]
		if len(sent.strip('。').strip('！').strip('？').strip(' ')) != 0:
			sent = sent.split('……')
			sentences += sent
	return sentences


def trans_to_json(dataset_file, split_sen=False):
	"""
	数据集转换成百度阅读理解竞赛中的测试集数据形式
	:param dataset_file:
	:return:
	"""
	jieba_seg = lambda content: jieba.lcut(content)
	samples = []
	json_file_suffix = "_sen.json" if split_sen else ".json"
	with open(dataset_file, "r") as file, open(dataset_file.split(".csv")[0]+json_file_suffix, "w", encoding="utf-8") as wfile:
		csv_reader = csv.reader(file, delimiter='\t', quoting=csv.QUOTE_NONE)
		for lid, line in enumerate(csv_reader):
			if lid == 0:
				continue
			com_sentences = split_comment_sentences(line[1]) if split_sen else [line[1]]
			for cid, com_sen in enumerate(com_sentences):
				sample = dict()
				sample["question"] = com_sen # question < comment
				sample["segmented_question"] = jieba_seg(com_sen)
				sample["question_id"] = line[0]+"_"+str(cid) # 分句
				sample["question_type"] = "DESCRIPTION"
				sample["fact_or_opinion"] = "FACT"
				documents = [{"paragraphs": [line[3]],
								"segmented_title": jieba_seg(com_sen),
								"segmented_paragraphs": [jieba_seg(line[3])],
								"title": com_sen}]
				sample["documents"] = documents
				samples.append(json.dumps(sample, ensure_ascii=False))
			if lid % 1000 == 0:
				wfile.write("\n".join(samples))
				wfile.write("\n")
				samples = []
		wfile.write("\n".join(samples))
	print("Trans to json done!")


def score_analysis(data, reverse=True):
	'''得分情况统计'''
	x = [1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0]
	y = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
	if not reverse: data.reverse()
	data_len = len(data)
	for i in range(0, data_len):
		for j in range(len(x)-1):
			if x[j] > data[i] >= x[j+1]:
				y[j] += 1
	print(y)
	print([round(i/data_len, 4) for i in y])
	print(data_len)


def trans_to_csv(json_file, dataset_file, tar_file, split_sen=False, order=False):
	"""
	预测结果json转为csv文件
	预测结果文件为答案部分内容
	转为问题、答案、评论、答案部分内容
	split_sen
	:return:
	"""
	with open(json_file, "r", encoding="utf-8") as jsonfile, open(dataset_file, "r") as datasetfile:
		with open(tar_file, "w") as tarfile:
			pre_answer = dict()
			for lid, line in enumerate(jsonfile):
				try:
					sample = json.loads(line.strip())
					comments_id = sample['question_id'].split('_')
					assert len(comments_id) == 2
					comment_id, comment_order = comments_id
					comment_order = int(comment_order)
					pre_answer_content = sample['answers'][0]
					pre_answer_score = sample['answers_score'][0]
					if comment_id not in pre_answer:
						pre_answer[comment_id] = [[pre_answer_content, pre_answer_score, comment_order]]
					else:
						pre_answer[comment_id].append([pre_answer_content, pre_answer_score, comment_order])
				except Exception as e:
					print(e)
					continue
			csv_reader = csv.reader(datasetfile, delimiter='\t', quoting=csv.QUOTE_NONE)
			csv_writer = csv.writer(tarfile, dialect='excel', delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\')
			csv_writer.writerow(["id", "content", "predict", "predict_score"])
			# 测试集1，问答对均不同 问题 答案 评论 预测的评论点
			# 按照问答对，评论、评论的第几句的顺序写入文件\
			if split_sen and not order:
				for lid, line in enumerate(csv_reader):
					if lid == 0:
						print(line)
						continue
					try:
						# if lid > 200: break
						# assert len(line) == 6
						answer = line[3]
						answer = answer.replace(',', "，")
						answer_sens_count = len(split_answer_sentences(answer))
						if 2 < answer_sens_count <= 5:                               # 查看答案为3-5句的情况
							predict_answers = sorted(pre_answer[line[0]], key=lambda x: x[-1], reverse=False)
							csv_writer.writerow([line[-2], line[-1], '', ''])        # 问题
							answer = line[-3].replace(',', '，')
							csv_writer.writerow([line[-4], answer, '', ''])        # 答案
							comment = line[1].replace(',', '，')
							csv_writer.writerow([line[0], comment])
							com_sentences = split_comment_sentences(line[1])
							for cid, predict_ans in enumerate(predict_answers):
								pre_answer_con, pre_answer_score, comment_order = predict_ans
								csv_writer.writerow([cid, com_sentences[cid], pre_answer_con, pre_answer_score])
							csv_writer.writerow([' ', ' ', ' ', ' '])
					except Exception as e:
						raise ValueError(e)
				print("Trans to csv Done")
			elif order:
				# 得分top n的数据样例 按得分降序排列
				score_data = []
				pre_in_answer_sentence = [0, 0, 0] # 预测结果前三句
				pre_content_length = 0             #预测结果的平均长度
				comment_length = 0                 # 评论句的平均长度
				item_count = 0
				pre_answer_by_score = []
				for key, value in pre_answer.items():
					for item in value:
						pre_answer_by_score.append([key, item[-1], item[0], float(item[1])])       # comment_id order content score
				pre_answer_by_score = sorted(pre_answer_by_score, key=lambda x: x[-1], reverse=True)
				comments_dict = dict()
				for lid, line in enumerate(csv_reader):
					if lid == 0: continue
					assert len(line) == 6
					comments_dict[line[0]] = line[1:]
				for item in pre_answer_by_score:
					c_con, a_id, a_con, q_id, q_con = comments_dict[item[0]]
					ans_sentences = split_answer_sentences(a_con)
					a_sen_count = len(ans_sentences)
					a_con = a_con.replace(',', '，')
					score_data.append(item[3])
					if a_sen_count < 3: continue # 根据答案句子数分开长答案和短答案
					# 预测结果在前三句的数目
					for i in range(3):
						if item[2] in ans_sentences[i]:
							pre_in_answer_sentence[i] += 1
					pre_content_length += len(item[2])
					item_count += 1
					csv_writer.writerow([q_id, q_con, '', ''])  # 问题
					csv_writer.writerow([a_id, a_con, '', ''])     # 答案
					c_con = c_con.replace(',', '，')
					csv_writer.writerow([item[0], c_con, '', ''])  # 评论
					com_sentences = split_comment_sentences(c_con)
					sentence = com_sentences[int(item[1])]         # 评论第几句
					comment_length += len(sentence)
					csv_writer.writerow(['第{}句'.format(int(item[1])+1), sentence, item[2], str(item[3])])
					csv_writer.writerow(['', '', '', ''])          # 空行隔开
				print("csv writer done by score")
				# 统计得分情况，预测的平均长度，预测结果在第一句中的比例。预测出为整句和片段各自比例
				print("数据条数：{} 预测的答案内容平均长度：{} 评论句平均长度：{}".format(item_count,
						pre_content_length/item_count, comment_length/item_count))
				print("预测结果在答案前三句的数目和比例{} {}".format(pre_in_answer_sentence,
						[item/item_count for item in pre_in_answer_sentence]))
				print("得分情况:")
				score_analysis(score_data)
			elif not split_sen and not order:
				# 未分句，不用排序
				# 问答对的形式写入
				qa_pair = {}
				for lid, line in enumerate(csv_reader):
					if lid == 0:
						print(line)
						continue
					answer_id = line[2]
					answer = line[3].replace(',', '，')
					if answer_id not in qa_pair:
						# [answer qid question [[cid, comment, predict, score, order]] ]
						qa_pair[answer_id] = [answer, line[4], line[5], [[line[0], line[1]]+pre_answer[line[0]][0][:-1]]]
					else:
						qa_pair[answer_id][-1].append([line[0], line[1]]+pre_answer[line[0]][0][:-1])
				print(len(qa_pair))
				for key, value in qa_pair.items():
					ans_sen_count = len(split_answer_sentences(value[0]))
					ans_word_count = len(value[0])
					if not (ans_sen_count >= 3): continue
					csv_writer.writerow([value[1], value[2], '', ''])
					csv_writer.writerow([key, value[0], '', ''])
					for cid, c_con, pre_con, pre_score in value[-1]:
						c_con = c_con.replace(',', '，')
						csv_writer.writerow([cid, c_con, pre_con, pre_score])
					csv_writer.writerow(['', '', '', ''])
			else:
				print("wrong option")


def answer_sentences_analysis(datafile):
	"""
	答案句子数目
	:param datafile:
	:return:
	"""
	with open(datafile, "r") as df, open(datafile.split(".csv")[0]+"_sen_1_2.csv", "w") as wfile:
		csv_reader = csv.reader(df, delimiter='\t', quoting=csv.QUOTE_NONE)
		csv_writer = csv.writer(wfile, dialect='excel', delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\')
		answer_sentences_counter = {}
		answer_id_set = set()
		for lid, line in enumerate(csv_reader):
			if lid == 0:
				csv_writer.writerow(["question_id", "question", "answer_id", "answer", "comment_id", "comment"])
				continue
			answer_id = line[2]
			answer = line[3].replace(',', '，')
			comment = line[1].replace(',', '，')
			sen_count = len(split_answer_sentences(answer))
			if sen_count < 3:
				csv_writer.writerow([line[-2], line[-1], line[2], answer, line[0], comment])
			if answer_id not in answer_id_set:
				if sen_count not in answer_sentences_counter:
					answer_sentences_counter[sen_count] = 1
				else:
					answer_sentences_counter[sen_count] += 1
				answer_id_set.add(answer_id)
		sum_answer = len(answer_id_set)
		print(sum_answer)
		answer_sentences_counter = sorted(answer_sentences_counter.items(), key=lambda x: x[0], reverse=False)
		answer_sentences_counter_ratio = [[length, counter, counter/sum_answer] for length, counter in answer_sentences_counter]
		for i in range(10):
			item = answer_sentences_counter_ratio[i]
			print(item)
		# import pickle
		# with open(datafile.split(".csv")[0]+"_answer_sen_count_ratio.pkl", "wb") as wf:
		# 	pickle.dump(answer_sentences_counter_ratio, wf)


def merge_file(tarfile, srcfiles):
	with open(tarfile, "w") as tfile:
		csv_writer = csv.writer(tfile, delimiter='\t', quoting=csv.QUOTE_NONE, escapechar='\\')
		csv_writer.writerow(["comment_id", "comment", "answer_id", "answer", "question_id", "question"])
		for srcfile in srcfiles:
			with open(srcfile, 'r') as sfile:
				csv_reader = csv.reader(sfile, delimiter='\t', quoting=csv.QUOTE_NONE)
				for lid, line in enumerate(csv_reader):
					if lid == 0: continue
					csv_writer.writerow(line)
	print("merge file done")

def main():
	all_data_file = "../data/data/comment/good_comment_fix.csv"

	train_dataset = "../dataset/dataset/trainset.csv"
	test1_dataset = "../dataset/dataset/testset1.csv"
	test2_dataset = "../dataset/dataset/testset2.csv"
	valid1_dataset = "../dataset/dataset/validset1.csv"
	valid2_dataset = "../dataset/dataset/validset2.csv"

	# sample_data = "../data/data/comment/good_comment_in_qa_len_filter_sample.csv"
	all_dataset = "../dataset/dataset/all_dataset.csv"
	merge_file(all_dataset, [train_dataset, test1_dataset, test2_dataset, valid1_dataset, valid2_dataset])
	# all_data = read_all_data(all_data_file)
	# fix数据集
	# fix_answer_content(all_data, train_dataset)
	# fix_answer_content(all_data, test1_dataset)
	# fix_answer_content(all_data, test2_dataset)
	# fix_answer_content(all_data, valid1_dataset)
	# fix_answer_content(all_data, valid2_dataset)
	# fix_answer_content(all_data, '../data/data/comment/sample/good_comment_10388_sample.csv')
	# fix_answer_content(all_data, sample_data)        # fix 采样数据

	# 采样数据转为json
	# sample_data_fix = "../data/data/comment/sample/zhihu_sample_fix.csv"
	# trans_to_json(sample_data_fix)
	# trans_to_json(sample_data_fix, True)

	# MR模型预测结果，json转csv文件
	# trans_to_csv("../user_focus_answer/mr_model/zhihu.sample.json", sample_data_fix,
	# 				"../user_focus_answer/mr_model/zhihu.sample.score.answer_sen_less_3.csv", order=True)
	# trans_to_csv("../user_focus_answer/mr_model/zhihu.sample.sen.json", sample_data_fix,
	# 				"../user_focus_answer/mr_model/zhihu.sample_sen.score.answer_sen_bigger_3.csv", order=True)

	# 答案句子数目分析
	# answer_sentences_analysis(sample_data_fix)
	# answer_sentences_analysis(test1_dataset)
	# answer_sentences_analysis(test2_dataset)
	# answer_sentences_analysis(sample_data.split(".csv")[0]+"_sample_fix.csv")
	# answer_sentences_analysis(train_dataset.split(".csv")[0]+'_fix.csv')


if __name__ == '__main__':
	main()
