#!/usr/bin/python2
# coding=utf-8
"""
process data to dataset of experiment
"""
from __future__ import print_function
from __future__ import division
from codecs import open
from collections import Counter
import re, csv, sys, pickle, datetime, random
import numpy as np

csv.field_size_limit(sys.maxsize)


def squeeze_char(comment):
    """压缩重复字符"""
    if len(comment) < 3: return comment
    flag = 0
    i = len(comment) - 1
    while i >= 0:
        if len(comment) < 2: break
        if comment[i] == comment[i-1] and comment[i-1] == comment[i-2]:
            flag = 1
            comment = comment[:i-1] + comment[i:]
        else:
            if flag == 1 and comment[i] == comment[i-1]:
                comment = comment[:i-1] + comment[i:]
                flag = 0
        i -= 1
    return comment


def normalize_comment(comment):
    """
    Normalization comment
    去掉标点符号，数字重复，符号重复，emoji
    :param com: comment
    :return: stem expression comment
    """
    # 符号表情
    symbol_expression = [r'=A=', r'=A=', r'QWQ', r'0v0', r'(⊙o⊙)', r'ԅ¯ㅂ¯ԅ ', r'´･ᆺ･`', r'ಥಥ', r'\≧▽≦',
                         r'ಡωಡ', r'←←', r'・ω・╰ひ╯', r'ง•̀•́ง', r'╯‵□′╯︵┻━┻', r'๑••๑', r'｡･ω･｡ﾉ♡',
                         r'╭′•o•′╭☞', r'o≧▽≦ツ┏━┓', r'ﾟДﾟ', r'з∠', r'•̀∀•́', r'┏━━┓', r'┏━┛', r'┏┓', r'┃',
                         r'┗┛', r'┗━━┛', r'´･ω･`', r'๑˙ー˙๑', r'๑•̀ㅂ•', r'づ｡◕‿‿◕｡づ', r'ﾟДﾟ']
    for sym in symbol_expression:
        comment = re.sub(sym, '', comment)
    # 标点符号
    comment = re.sub(r'-', '', comment)
    punctuation = '[\s+\.\!\/_,$%^*(+\"\')]+|[+——()?【】“”！，。？♂●：》=|「」○￣《～→:、~@#￥%……&*（）]+'
    comment = re.sub(punctuation, '', comment)
    num_pattern ='[①②③④⑤⑦⑧⑨⑩]+'
    comment = re.sub(num_pattern, '', comment)
    # 去除emoji
    emoji_pattern = [u'[\u2700-\u27BF]', u'[\uE001-\uE05A]', u'[\uE101-\uE15A]', u'[\uE201-\uE253]', u'[\uE301-\uE34D]',
                     u'[\uE401-\uE44C]', u'[\uE501-\uE537]']
    for e_p in emoji_pattern:
        comment = re.sub(e_p, '', comment)
    emoji = [r'🌚', r'😂', r'🐸', r'👍', r'😭', r'😄', r'😳', r'💪', r'💪🏻', r'😱', r'😊', r'👍🏻', r'㊗️',
             r'💯', r'😒', r'👏']
    for e in emoji:
        comment = re.sub(e, '', comment)
    # 连续重复数字/重复汉字/重复字母
    comment = squeeze_char(comment)
    return comment


def data_filter(filepath):
	"""
	清洗数据，答案内容、评论内容的清洗
	:param filepath:
	:return:
	"""
	with open(filepath, "r") as f:
		csv_read = csv.reader(f, delimiter="\t", quoting=csv.QUOTE_NONE)
		with open(filepath.split(".csv")[0]+"_filter.csv", "w") as wf:
			csv_write = csv.writer(wf, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
			re_pattern = r'<[a-z]{1,6}>|<\/[a-z]{1,6}>|<img.*>|<video.*></video>|<a.*>'
			samples, count = [], 0
			with open("filter_example.txt", "w") as ff:
				for id, line in enumerate(csv_read):
					if id == 0:
						csv_write.writerow(line)
						continue
					comment, answer, question = line[1], line[3], line[5]
					comment = re.sub(re_pattern, '', comment)
					answer = re.sub(re_pattern, '', answer)
					question = re.sub(re_pattern, '', question)
					if len(comment) == 0 or len(answer) == 0 or len(question) == 0 or comment == 'NULL' \
						or answer == "NULL" or question == "NULL":
						ff.write("\n".join(line))
						ff.write("\n"+"*"*100+"\n")
						continue
					samples.append([line[0], comment, line[2], answer, line[4], question])
					if id % 200000 == 0:
						print(id, datetime.datetime.now())
						csv_write.writerows(samples)
						count += len(samples)
						samples = []
			count += len(samples)
			csv_write.writerows(samples)
			print("清洗数据后评论数目:{}".format(count))


def dataset_filter_repeated_comment(filepath):
	"""
	对评论标准化为stem expression，比较问答对内重复的评论，问答对间重复的评论
	:return:
	"""
	qa_pair_sample = dict()
	comment_count = 0
	with open(filepath, "r") as f:
		csv_read = csv.reader(f, delimiter="\t", quoting=csv.QUOTE_NONE)
		for lid, line in enumerate(csv_read):
			if lid == 0: continue
			comment_count += 1
			ans_id = line[2]
			if ans_id not in qa_pair_sample:
				qa_pair_sample[ans_id] = [(line[0], line[1], line[3], line[4], line[5])]
			else:
				qa_pair_sample[ans_id].append((line[0], line[1], line[3], line[4], line[5]))
		print("qa_pair: {} comment_count:{}".format(len(qa_pair_sample), comment_count))
		nor_comment_count = 0
		with open("问答对内的重复评论.txt", "w") as qainf:
			for key, value in qa_pair_sample.items():
				# 同一问答对下的评论  出现多次，都去除
				nor_value = []
				nor_c_cons = [] #
				for c_id, c_con, a_con, q_id, q_con in value:
					nor_c_con = normalize_comment(c_con)  #normalize comment
					nor_value.append([c_id, c_con, nor_c_con, a_con, q_id, q_con])
					nor_c_cons.append(c_con)
				nor_c_count = Counter(nor_c_cons) # nor c cons
				new_value = []
				for c_id, c_con, nor_c_con, a_con, q_id, q_con in nor_value:
					nor_c_con_count = nor_c_count[nor_c_con]
					if nor_c_con_count > 1:
						qainf.write("{} \t {}\n".format(nor_c_con, nor_c_con_count))
						continue
					new_value.append([c_id, c_con, nor_c_con, a_con, q_id, q_con])
				qa_pair_sample[key] = new_value
				nor_comment_count += len(new_value)
		print("问答对内 normalization comment:{} 差值:{}".format(nor_comment_count, comment_count-nor_comment_count))
		# 问答对间的评论
		qa_comment_dict = dict()
		for key, value in qa_pair_sample.items():
			for c_id, c_con, nor_c_con, a_con, q_id, q_con in value:
				if nor_c_con not in qa_comment_dict:
					qa_comment_dict[nor_c_con] = [(c_id, c_con, key, a_con, q_id, q_con)]
				else:
					qa_comment_dict[nor_c_con].append((c_id, c_con, key, a_con, q_id, q_con))
		qa_comment_list = sorted(qa_comment_dict.items(), key=lambda x: len(x[1]), reverse=True)
		# 问答间的评论，人工查看后，出现两次以上的都去除
		qa_comment_count = 0
		with open("问答对间重复评论.txt", "w") as qaf:
			with open("../data/data/comment/good_comment_in_qa.csv", "w") as wf:
				csv_write = csv.writer(wf, delimiter='\t', quoting=csv.QUOTE_NONE, escapechar='\\')
				csv_write.writerow(["comment_id", "comment", "nor_c_con","answer_id", "answer", "question_id", "question"])
				for i in range(len(qa_comment_list)):
					sample = qa_comment_list[i]
					if len(sample[1]) > 1:
						# print("问答对间的重复评论 {} 数目 {}".format(sample[0], len(sample[1])))
						qaf.write("{} \t {}\n".format(sample[0], len(sample[1])))
					else:
						qa_comment_count += len(sample[1])
						for c_id, c_con, a_id, a_con, q_id, q_con in sample[1]:
							csv_write.writerow([c_id, c_con, sample[0], a_id, a_con, q_id, q_con])
	print("去除问答对间重复评论后:{}".format(qa_comment_count))
	print("Done")


def data_len_filter(filepath):
	"""
	筛去评论长度小于5的数据//观察发现，小于5的短评论包含的意义不大
	筛去答案长度小于10的数据// 问题长度小于5
	:param filepath:
	:return:
	"""
	with open(filepath, "r") as f:
		csv_read = csv.reader(f, delimiter="\t", quoting=csv.QUOTE_NONE)
		with open(filepath.split(".csv")[0]+"_len_filter.csv", "w") as wf:
			csv_write = csv.writer(wf, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
			for lid, line in enumerate(csv_read):
				if lid == 0:
					csv_write.writerow(line)
					continue
				if len(line[1]) < 5 or len(line[-1]) < 5 or len(line[-3]) < 10:
					continue
				csv_write.writerow(line)
	print("Done")


def data_caculate(filepath):
	"""
	读数据，统计优质评论数据中答案下评论分布情况：
	:return:
	"""
	with open(filepath, "r") as rf:
		answer_dict = {}
		question_dict = {}
		csv_Reader = csv.reader(rf, delimiter='\t', quoting=csv.QUOTE_NONE)
		c_id = 0
		for id, line in enumerate(csv_Reader):
			if id == 0:
				print(line)
				continue
			assert len(line) == 7
			if line[3] in answer_dict:
				answer_dict[line[3]] += 1
			else:
				answer_dict[line[3]] = 1
			if line[-2] in question_dict:
				if line[3] not in question_dict[line[-2]]:
					question_dict[line[-2]].add(line[3])
			else:
				question_dict[line[-2]] = set([line[3]])
			c_id = id+1
		print("comment_count:{}".format(c_id))
		print("answer_count:{}".format(len(answer_dict)))
		answer_comments_num = [comments_num for answer_id, comments_num in answer_dict.items()]
		answer_comments_num = sorted(Counter(answer_comments_num).items()) # 答案具有的评论数目：对应的答案数目
		with open(filepath.split(".csv")[0]+"_answer_comment.pkl", "wb") as acf:
			pickle.dump(answer_comments_num, acf)
		print("question_count:{}".format(len(question_dict)))
		question_answers_num = [len(value) for key, value in question_dict.items()]
		question_answers_num = sorted(Counter(question_answers_num).items())
		with open(filepath.split(".csv")[0]+"_question_answer.pkl", "wb") as qaf:
			pickle.dump(question_answers_num, qaf)
	print("Done")


def sample_dataset(filepath):
	"""
	数据抽样查看是否存在无意义的短评论
	以评论的长度排序，查看情况
	:return:
	"""
	data_comment_sample = {}
	data_answer_sample = {}
	data_question_sample = {}
	answer_id_set = set()
	question_id_set = set()
	with open(filepath, "r") as rf:
		csv_reader = csv.reader(rf, delimiter='\t', quoting=csv.QUOTE_NONE)
		for id, line in enumerate(csv_reader):
			if id == 0: continue
			comment_len = len(line[1])
			if comment_len < 10:
				if comment_len not in data_comment_sample:
					data_comment_sample[comment_len] = [(line[0], line[1], line[3])]
				else:
					data_comment_sample[comment_len].append((line[0], line[1], line[3]))
			if line[2] not in answer_id_set: # 较短的答案情况
				answer_id_set.add(line[2])
				answer_len = len(line[3])
				if answer_len < 20:
					if answer_len not in data_answer_sample:
						data_answer_sample[answer_len] = [(line[2], line[3], line[4], line[5])]
					else:
						data_answer_sample[answer_len].append((line[2], line[3], line[4], line[5]))
			if line[4] not in question_id_set:
				question_id_set.add(line[4])
				question_len = len(line[5])
				if question_len < 10:
					if question_len not in data_question_sample:
						data_question_sample[question_len] = [(line[4], line[5])]
					else:
						data_question_sample[question_len].append((line[4], line[5]))
	count = 0
	for key, value in data_comment_sample.items():
		print(key, len(value))
		count += len(value)
		with open("../sample/"+str(key)+"_c_len.csv", "w") as f:
			csv_writer = csv.writer(f, dialect=("excel"), delimiter=',', quoting=csv.QUOTE_NONE,  escapechar='\\')
			csv_writer.writerow(['answer', 'comment_id', 'comment'])
			comment_dict = {}
			for cid, con, ans in value:
				csv_writer.writerow([ans, cid, con])
				if con in comment_dict:
					comment_dict[con].append((cid, ans))
				else:
					comment_dict[con] = [(cid, ans)]
			print(key, len(comment_dict))
			if len(comment_dict) > 0:
				rcount = 0
				with open("../sample/repeat_comment"+str(key)+".txt", "w") as wf:
					for key1, value1 in comment_dict.items():
						if len(value1) > 1:
							rcount += 1
							for cid, ans in value1:
								wf.write(ans+"\n"+cid+"\n"+key1)
								wf.write("\n"+"*"*100+"\n")
				print(rcount, len(value), rcount/len(value))
	acount = 0
	print("answer length")
	for key, value in data_answer_sample.items():
		print(key, len(value))
		acount += len(value)
		with open("../sample/"+str(key)+"_a_len.csv", "w") as f:
			csv_writer = csv.writer(f, dialect=("excel"), delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\')
			csv_writer.writerow(["question_id", "question", "answer_id", "answer"])
			for aid, acon, qid, qcon in value:
				csv_writer.writerow([qid, qcon, aid, acon])
	print(acount)

	qcount = 0
	print("question length")
	for key, value in data_question_sample.items():
		print(key, len(value))
		qcount += len(value)
		with open("../sample/"+str(key)+"_q_len", "w") as qf:
			csv_writer = csv.writer(qf, dialect=("excel"), delimiter=',', quoting=csv.QUOTE_NONE, escapechar='\\')
			csv_writer.writerow(["question_id", "question"])
			for qid, qcon in value:
				csv_writer.writerow([qid, qcon])
	print(qcount)


def dataset_devide(filepath):
	"""
	划分数据集
	根据上述统计结果划分数据集，说结果相对理想即大部分答案只有一条优秀评论，按比例进行划分。
	否则在选验证集时对每个答案下评论选一条
	## 统计结果显示 评论数据中 69w(699314)答案中只有一条评论的有43w(433881) 1351850评论
	:return:
	"""
	data_samples = []
	row_name = []
	with open(filepath, "r") as f:
		csv_read = csv.reader(f, delimiter='\t', quoting=csv.QUOTE_NONE)
		for lid, line in enumerate(csv_read):
			if lid == 0:
				row_name = line
				continue
			data_samples.append(line)
	random.shuffle(data_samples)
	print("shuffle done")
	# 划分比例：8:1:1
	data_len = len(data_samples)
	train_len, test_len, valid_len = 0, 0, 0
	with open(filepath.split(".csv")[0]+"_train.csv", "w") as trainf:
		with open(filepath.split(".csv")[0]+"_test.csv", "w") as testf:
			with open(filepath.split(".csv")[0]+"_valid.csv", "w") as validf:
				train_write = csv.writer(trainf, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
				test_write = csv.writer(testf, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
				valid_write = csv.writer(validf, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
				train_write.writerow(row_name)
				test_write.writerow(row_name)
				valid_write.writerow(row_name)
				for id, sample in enumerate(data_samples):
					if id < data_len*0.8:
						train_write.writerow(sample)
						train_len += 1
					elif id < data_len*0.9:
						test_write.writerow(sample)
						test_len += 1
					else:
						valid_write.writerow(sample)
						valid_len += 1
	# trainset:1081480 testset:135185 validset:135184
	print("trainset:{} testset:{} validset:{}".format(train_len, test_len, valid_len))
	

def dataset_caculate(filepath):
	"""
	通过数据集差异：
	评论的长度，答案长度，问题长度差异（均值，方差，最值）
	:return:
	"""
	comment_len = []
	answer_len_uni, answer_id = [], set()
	question_len_uni, question_id = [], set()
	answer_len = []
	question_len = []
	with open(filepath, "r") as rf:
		csv_reader = csv.reader(rf, delimiter='\t', quoting=csv.QUOTE_NONE)
		for id, line in enumerate(csv_reader):
			if id == 0: continue
			try:
				comment_len.append(len(line[1]))
			except:
				print(line)
				return
			# answer_len.append(len(line[3]))
			answer_length = len(line[-3])
			answer_len.append(answer_length)
			question_len.append(len(line[-1]))
			if line[-4] not in answer_id:
				answer_id.add(line[-4])
				# answer_len_uni.append(len(line[3]))
				answer_len_uni.append(answer_length)
			if line[-2] not in question_id:
				question_id.add(line[-2])
				question_len_uni.append(len(line[-1]))
	comment_length = sorted(Counter(comment_len).items(), key=lambda x: x[0], reverse=False)
	answer_length = sorted(Counter(answer_len_uni).items(), key=lambda x: x[0], reverse=False)
	question_length = sorted(Counter(question_len_uni).items(), key=lambda x: x[0], reverse=False)
	with open("dataset_length.pkl", "wb") as f:
		pickle.dump(comment_length, f)
		pickle.dump(answer_length, f)
		pickle.dump(question_length, f)

	log0 = "{} 统计:\n".format(filepath.split(".csv")[0])
	log1 = "评论 数目:{} 均值:{} 方差:{} 最大值:{} 最小值:{} 中位数:{} 众数:{}\n".format(len(comment_len),
			np.mean(comment_len), np.sqrt(np.var(comment_len)), np.max(comment_len), np.min(comment_len),
			np.median(comment_len), np.argmax(np.bincount(comment_len)))

	log2 = "答案 数目:{} 均值:{} 方差:{} 最大值:{} 最小值:{} 中位数:{} 众数:{}\n".format(len(answer_len),
			np.mean(answer_len), np.sqrt(np.var(answer_len)), np.max(answer_len), np.min(answer_len),
			np.median(answer_len), np.argmax(np.bincount(answer_len)))

	log3 = "问题 数目:{} 均值:{} 方差:{} 最大值:{} 最小值:{} 中位数:{} 众数:{}\n".format(len(question_len),
			np.mean(question_len), np.sqrt(np.var(question_len)), np.max(question_len), np.min(question_len),
			np.median(question_len), np.argmax(np.bincount(question_len)))

	log4 = "不同答案 数目:{} 均值:{} 方差:{} 最大值:{} 最小值:{} 中位数:{} 众数:{}\n".format(len(answer_len_uni),
			np.mean(answer_len_uni), np.sqrt(np.var(answer_len_uni)), np.max(answer_len_uni), np.min(answer_len_uni),
			np.median(answer_len_uni), np.argmax(np.bincount(answer_len_uni)))

	log5 = "不同问题 数目:{} 均值:{} 方差:{} 最大值:{} 最小值:{} 中位数:{} 众数:{}\n".format(len(question_len_uni),
			np.mean(question_len_uni), np.sqrt(np.var(question_len_uni)), np.max(question_len_uni),
			np.min(question_len_uni), np.median(question_len_uni), np.argmax(np.bincount(question_len_uni)))
	print(log0, log1, log2, log3, log4, log5)
	with open(filepath.split(".csv")[0]+"_caculate.txt", "w") as wf:
		wf.write(log0+log1+log2+log3+log4+log5)


def dataset_qa_pair(filepath, dataset_dir="../dataset/"):
	"""
	划分方案：
	以问题-答案的组合作为唯一id（即问题、答案有一个不同就是不同的id），
	一个id下仅有1个评论的都进集合a；
	一个id下仅有2-8个评论的给集合z；
	一个id下有9个及以上评论的一个给集合t，一个给集合d，一个给d‘，剩下的都是集合aa
	t：测试集1
	{特别要求：存储每个测试评论的训练集合中同id训练样本个数，日后实验分析的时候很有用；
	例如 id=5 的 一个测试评论，那么它的 #ts（No. of training smaple）=3}
	t‘ ：测试集2：
	a等距离分成|t|份，每份随机出来两个样本，一个进t’（另一个进d）
	d：开发集1；肯定等于t+t'；
	d+d' 开发集2，日后补充实验用
	aa+z+和剩下的a，都是训练集
	:return:
	"""
	pair_qa = dict()
	with open(filepath, "r") as rf:
		csv_reader = csv.reader(rf, delimiter='\t', quoting=csv.QUOTE_NONE)
		for id, line in enumerate(csv_reader):
			assert len(line) == 7
			if id == 0: continue
			answer_id = line[3]
			if answer_id not in pair_qa:
				# qa_pair  [a_con, q_id, q_con, [[c_id, c_con], [..]...]
				pair_qa[answer_id] = [line[-3], line[-2], line[-1], [[line[0], line[1]]]]
			else:
				pair_qa[answer_id][-1].append([line[0], line[1]])
	# 问答对数目
	print("qa_pair num", len(pair_qa))
	# 抽取测试集
	a_set, z_set, t_set = [], [], []
	aa_set, d_set, dd_set = [], [], []
	for key, value in pair_qa.items():
		comments = value[-1]
		comment_num = len(comments)
		if comment_num == 1:
			# [a_id, a_con, q_id, q_con, c_id, c_con]
			a_set.append([key]+value[:-1]+value[-1][0])
		elif 1 < comment_num < 9:
			for c_id, c_con in value[-1]:
				z_set.append([key]+value[:-1]+[c_id, c_con])
		else:
			t_set.append([key]+value[:-1]+value[-1][0])
			d_set.append([key]+value[:-1]+value[-1][1])
			dd_set.append([key]+value[:-1]+value[-1][2])
			for i in range(3, comment_num):
				c_id, c_con = value[-1][i]
				aa_set.append([key]+value[:-1]+[c_id, c_con])
	# t:测试集1
	t_set_len = len(t_set)
	print("t:测试集1 {}".format(t_set_len))
	# t':测试集2
	tt_set, a_final_set = [], []
	chunks = len(a_set)/t_set_len
	# 存疑，最后一个chunk太小 9622
	print("chunks: {}  last chunk size: {}".format(chunks, len(a_set)-int(chunks)*t_set_len))
	chunks = int(chunks)
	for j in range(0, t_set_len):
		chunk_data = a_set[j*chunks:(j+1)*chunks]
		random.shuffle(chunk_data)
		assert len(chunk_data) != 0
		sample1 = chunk_data.pop()
		sample2 = chunk_data.pop()
		tt_set.append(sample1)
		d_set.append(sample2)
		a_final_set += chunk_data
	print("t':测试集2 {}".format(len(tt_set)))
	print("d:开发集1 {}".format(len(d_set)))
	valid_data2 = d_set + dd_set
	print("d+d':开发集2 {}".format(len(valid_data2)))
	# 开发集1等于t+t'
	assert len(d_set) == len(t_set)+len(tt_set)
	train_data = aa_set+z_set+a_final_set
	print("aa+z+final_a 训练集 {}".format(len(train_data)))
	# 测试集中每个问答对在训练集中出现的次数 pkl存储
	train_qa_ids = {}
	for item in train_data:
		if item[0] not in train_qa_ids:
			train_qa_ids[item[0]] = 1
		else:
			train_qa_ids[item[0]] += 1
	test1_qa_ids = {item[0]: train_qa_ids[item[0]] for item in t_set if item[0] in train_qa_ids}
	test2_qa_ids = {item[0]: train_qa_ids[item[0]] for item in tt_set if item[0] in train_qa_ids}
	with open(dataset_dir+"test_qa_freq_in_trainset.pkl", "wb") as tqa_file:
		pickle.dump(test1_qa_ids, tqa_file)
		pickle.dump(test2_qa_ids, tqa_file)
	# write dataset
	print("write to file")
	with open(dataset_dir+"trainset.csv", "w") as train_file:
		train_write = csv.writer(train_file, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
		train_write.writerow(["comment_id", "comment", "answer_id", "answer", "question_id", "question"])
		[train_write.writerow(item[-2:]+item[:-2]) for item in train_data]
	with open(dataset_dir+"testset1.csv", "w") as test_file1, open(dataset_dir+"testset2.csv", "w") as test_file2:
		test_write1 = csv.writer(test_file1, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
		test_write2 = csv.writer(test_file2, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
		test_write1.writerow(["comment_id", "comment", "answer_id", "answer", "question_id", "question"])
		test_write2.writerow(["comment_id", "comment", "answer_id", "answer", "question_id", "question"])
		[test_write1.writerow(item[-2:]+item[:-2]) for item in t_set]
		[test_write2.writerow(item[-2:]+item[:-2]) for item in tt_set]
	with open(dataset_dir+"validset1.csv", "w") as valid_file1, open(dataset_dir+"validset2.csv", "w") as valid_file2:
		valid_write1 = csv.writer(valid_file1, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
		valid_write2 = csv.writer(valid_file2, delimiter="\t", quoting=csv.QUOTE_NONE, escapechar='\\')
		valid_write1.writerow(["comment_id", "comment", "answer_id", "answer", "question_id", "question"])
		valid_write2.writerow(["comment_id", "comment", "answer_id", "answer", "question_id", "question"])
		[valid_write1.writerow(item[-2:]+item[:-2]) for item in d_set]
		[valid_write2.writerow(item[-2:]+item[:-2]) for item in valid_data2]
	print("written done in {}".format(dataset_dir))


def main():
	"""main"""
	filepath = "../data/data/comment/good_comment_unique.csv"
	# data_filter(filepath)
	filter_path = "../data/data/comment/good_comment_unique_filter.csv"
	# data_len_filter(filter_path)
	# filter_5_path = "../data/data/comment/good_comment_unique_filter_com_len_than5.csv"
	# sample_dataset(filter_path)
	# dataset_filter_repeated_comment(filter_path)
	# dataset_qa_pair(filter_path)
	file_in_qa = "../data/data/comment/good_comment_in_qa.csv"
	# sample_dataset(file_in_qa)
	# data_caculate(file_in_qa)
	# dataset_devide(filter_path)
	# dataset_caculate(file_in_qa)
	# data_len_filter(file_in_qa)
	file_len_fileter = "../data/data/comment/good_comment_in_qa_len_filter.csv"
	dataset_qa_pair(file_len_fileter)
	# dataset_caculate(file_len_fileter)
	dataset_dir = "../dataset/"
	dataset_caculate(dataset_dir+"trainset.csv")
	dataset_caculate(dataset_dir+"testset1.csv")
	dataset_caculate(dataset_dir+"testset2.csv")
	dataset_caculate(dataset_dir+"validset1.csv")
	dataset_caculate(dataset_dir+"validset2.csv")
	# data_caculate(file_len_fileter)
	# dataset_caculate(filter_path.split(".csv")[0]+"_train.csv")
	# dataset_caculate(filter_path.split(".csv")[0]+"_test.csv")
	# dataset_caculate(filter_path.split(".csv")[0]+"_valid.csv")


if __name__ == "__main__":
	main()


