#!/usr/bin/python2
# coding=utf-8
from __future__ import print_function
from __future__ import division
from codecs import open
import csv
import math
import sys
import os

csv.field_size_limit(sys.maxsize)

def caculate(data_dict, i):
    """
    计算极值、均值、众数、方差、中值等信息
    :return:
    """
    min_ ,max_ ,count_ ,sum_ = 1e5, 0, 0, 0
    data_list = []
    most_dict = dict()
    for key, value in data_dict.items():
        # print(value)
        num = int(value[i])
        if num == 0: continue
        data_list.append([value[0], num])
        if num in most_dict:
            most_dict[num] += 1
        else:
            most_dict[num] = 1
        min_ = num if min_ > num else min_
        max_ = num if max_ < num else max_
        count_ += 1
        sum_ += num
    print(max_, min_, sum_/count_)# 极大值 极小值 均值
    avg_ = sum_ / count_
    data_list = sorted(data_list, key=lambda x: x[1]) # 排序
    name, mid_num = data_list[int(len(data_list)/2)]
    print(name, mid_num) # 中数
    print(max(most_dict, key=most_dict.get)) # 众数
    theta = 0
    for x in data_list:
        theta += (x[1]-avg_)**2
    print(math.sqrt(theta)/count_) #方差
    
def read_file(filepath):
    """
    读取hive跑得的csv文件，统计其中的结果
    :return:
    """
    # ['q.domain_id', 'q.domain_name', 'q.domain_status', 'q.topic_num', 'q.topic_index_num', 'q.topic_followed_num', \
    # 'q.question_num', 'q.answer_num', 'q.column_num', 'q.article_num', 'q.p_year', 'q.p_month', 'q.p_day']
    data_dict = dict()
    with open(filepath) as csvf:
        pd_reader = csv.reader(csvf, delimiter='\t', quoting=csv.QUOTE_NONE)
        for l_id, line in enumerate(pd_reader):
            if l_id == 0:
                print(line)
                continue
            if len(line[1:]) > 0:
                data_dict[line[0]] = line[1:]
        print(len(data_dict))
        print("topic_num")
        caculate(data_dict, 2)
        print("topic_followed_num")
        caculate(data_dict, 3)
        print("question num")
        caculate(data_dict, 4)
        print("answer_num")
        caculate(data_dict, 5)
        print("column num")
        caculate(data_dict, 6)
        print("article num")
        caculate(data_dict, 7)
    

    
def main():
    print("domain static")
    filepath = "../data/domain.csv"
    read_file(filepath)
    
main()
