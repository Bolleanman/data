#!/usr/bin/python2
# coding=utf-8
from __future__ import print_function
from __future__ import division
from codecs import open
import matplotlib.pyplot as plt
import os, sys
import csv

csv.field_size_limit(sys.maxsize)
plt.switch_backend('agg')


def plot_xy(xls, yls, namex, namey, option):
	plt.scatter(xls, yls, marker=".", c='r')
	plt.xlabel(str(namex.split(".")[-1]))
	plt.ylabel(str(namey.split(".")[-1]))
	plt.savefig("../data/picture/{}/{}.{}.png".format(option, namey, namex))


def draw_pictures(data_ls, option, colname):
	row_len = len(colname)-1
	for i in range(2, row_len-12):
		for j in range(1, 13):
			print(colname[i], "-", colname[-j])
			plot_xy(data_ls[i], data_ls[-j], colname[i], colname[-j], option)


def cacultate(data, colname):
	row_len = len(colname)-1
	data_ls = [[] for _ in range(row_len)]
	count = 0
	for key, value in data.items(): # 20w data
		count += 1
		if len(value) == 0: continue
		if count%1 == 0: # 采样2w
			for i in range(row_len):
				if i<row_len-12:
					num = round(float(list(value[i])[1]), 4)
				else:
					num = round(float(value[i]), 4)
				data_ls[i].append(num)
	return data_ls

def caculate_static(datals, name, option):
	"""
	计算 均值、最值、方差、众数、中数
	:param data_dict:
	:return:
	"""
	data_ls = []
	most_dict = dict()
	max_num, min_num, sum_num, count = 0, 1e5, 0, 0
	valid_count = 0
	for idx, x in enumerate(datals):
		if 0 == x:
			count += 1
			continue
		max_num = x if x > max_num else max_num
		min_num = x if x < min_num else min_num
		count += 1
		valid_count += 1
		sum_num += x
		data_ls.append(x)
		if x in most_dict:
			most_dict[x] += 1
		else:
			most_dict[x] = 1
	data_ls = sorted(data_ls)
	print(valid_count)
	print("中数:", data_ls[int(len(data_ls)/2)])
	# max_index = max(most_dict, key=most_dict.get)
	most_ls = sorted(most_dict.items(), key=lambda x:x[1], reverse=True)
	print("众数:", most_ls[0])
	print("1-15的各个数目:")
	for item in range(0, 15):
		if item < len(most_ls):
			print(item, most_ls[item], most_ls[item][1]/valid_count)
	avg = sum_num/valid_count
	print("均值:", avg)
	print("最大值:", max_num, "最小值:", min_num)
	theta = 0
	for x in data_ls:
		theta += (x-avg)**2
	print("方差：", theta/valid_count)
	with open("../data/data/{}/{}.property.1.txt".format(option, option), "a") as f:
		f.write("\n {} \n".format(name))
		f.write("均值：{}  方差:{} \n".format(avg, theta))
		f.write("中数:{} \n".format(data_ls[int(len(data_ls)/2)]))
		f.write("最大值：{}  最小值: {} \n".format(max_num, min_num))
		f.write("众数:{} \n".format(most_ls[0]))
		f.write("1-15的各个数目:\n")
		for item in range(0, 15):
			if item < len(most_ls):
				f.write("{} \t {} \n".format(most_ls[item][0], most_ls[item][1] / valid_count))


def read_data(data_file):
	data = dict()
	colname = []
	with open(data_file) as csv_file:
		pd_reader = csv.reader(csv_file, delimiter='\t', quoting=csv.QUOTE_NONE)
		for l_id, line in enumerate(pd_reader):
			if l_id==0: colname = line; continue
			# if l_id==1:
			# 	print(colname)
			# 	print(line)
			# 	return
			if len(line) != 0:
				data[line[0]] = line[1:]
	return data, colname


def run_hive_sql(sql_file, tar_file):
	print("run hive sql for {}".format(sql_file.split(".")[0]))
	out = os.popen("hive -f {} > {}".format(sql_file, tar_file))
	print(out.read())


def run():
	option = sys.argv[1]
	sql_file = "{}.sql".format(option)
	tar_file = "../data/data/{}/{}.quality.csv".format(option, option)
	# run_hive_sql(sql_file, tar_file)
	data, colname = read_data(tar_file)
	print(colname)
	data_ls = cacultate(data, colname)
	# draw_pictures(data_ls, option, colname)
	for i in range(1, 13):
		print("\n*************\n")
		print(colname[-i])
		caculate_static(data_ls[-i], colname[-i], option)
run()