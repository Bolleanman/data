import sys


def main():
    sourcefile = sys.argv[1]
    tarfile = sys.argv[2]
    n = int(sys.argv[3])
    with open(sourcefile, "r") as f:
        with open(tarfile, "w") as wf:
            for lid, line in enumerate(f.read()):
                if lid<n:
                    wf.write(line)
                else:
                    break
        print("Done")
main()

