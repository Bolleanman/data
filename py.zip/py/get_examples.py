#!/usr/bin/python2
# coding=utf-8
"""
取出一些数据样例
"""
from __future__ import print_function
from __future__ import division
from codecs import open
import json
import csv
import sys

csv.field_size_limit(sys.maxsize)


def get_examples(filepath):
	with open(filepath) as rf:
		rf_reader = csv.reader(rf, delimiter='\t', quoting=csv.QUOTE_NONE)
		with open(filepath.split("csv")[0]+"examples.txt", "w") as wf:
			for lid, line in enumerate(rf_reader):
				if lid==0: continue
				if lid>1000:
					print(lid, line[0])
					break
				# print(line[1])
				wf.write("&"*20+"\n"+line[1]+"\n"+"*"*20+"\n"+line[3]+"\n")
	print('Done')


get_examples("../data/data/comment/good_comment.csv")
