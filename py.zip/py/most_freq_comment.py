#!/usr/bin/python2
# coding=utf-8
from __future__ import print_function
from __future__ import division
from codecs import open
from process_data import normalize_comment


def get_most_freq_comment(file):
	comment_freq = {}
	with open(file, 'r') as f:
		for line in f:
			data = line.strip('\n').split(' ')
			if len(data) != 2: continue
			org_comment, num = data
			num = int(num)
			comment = normalize_comment(org_comment)
			if comment in comment_freq:
				comment_freq[comment][1] += num
			else:
				comment_freq[comment] = [org_comment, num]
	comment_freq = sorted(comment_freq.items(), key=lambda x: x[1][1], reverse=True)
	for i in range(20):
		print(comment_freq[i])
	print("Done")


def main():
	file = "../data/data/comment/unique_comment.txt"
	get_most_freq_comment(file)


if __name__ == '__main__':
	main()