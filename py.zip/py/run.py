#!/usr/bin/python2
# coding=utf-8
from __future__ import print_function
from __future__ import division
from codecs import open
import os, sys, csv
import matplotlib.pyplot as plt
from scipy import optimize

csv.field_size_limit(sys.maxsize)
plt.switch_backend('agg')

def draw_picture(x_ls, y_ls, option, x_label, y_label):
	"""
	画趋势图,xy之间的关系
	:param data_xy:
	:param option:
	:return:
	"""
	# 排序
	# data = [[x_ls[i], y_ls[i]] for i in range(len(x_ls))]
	# 为、0的数太多，较为稀疏，去除为0的情况
	data = []
	for i in range(len(x_ls)):
		# if x_ls[i] == 0 or y_ls[i] == 0:
		# 	continue
		data.append([x_ls[i], y_ls[i]])
	data = sorted(data, key=lambda x: x[0])
	xls, yls = [], []
	thresh = int(0.99*len(data)) # 包含99.9%的数据，防止个别较大的点的影响
	y_max = max(y_ls)
	x_max = max(x_ls)
	count = 0
	for x, y in data:
		# if count > thresh: break
		# if count < start:
		# 	count += 1
		# 	continue
		# count += 1
		if y>y_max*0.05 or x>x_max*0.005: # 去除个别较大的值
			continue
		xls.append(x)
		yls.append(y)
	print(x_label, y_label)
	print(len(xls), len(x_ls), len(xls)/len(x_ls)) # 占比
	plt.scatter(xls, yls, marker=".", c='r')
	plt.xlabel(str(x_label.split("_")[0]))
	plt.ylabel(str(y_label.split("_")[0]))
	if len(xls) == 0: return
	plt.xlim(0, max(xls))
	plt.ylim(0, max(yls))
	plt.savefig("../data/{}/{}.png".format(option, x_label))

def question_type(data, k=-2):
	count = [0, 0, 0]
	no_c_count = [0, 0, 0]
	c_sum_count = [0, 0, 0]
	for key, value in data.items():
		q_type = int(value[k])
		for i in range(3):
			if q_type == i:
				count[i] += 1
				c_sum_count[i] += int(value[0])
				if int(value[0]) == 0:
					no_c_count[i] += 1
	for i in range(3):
		print(count[i], no_c_count[i], c_sum_count[i], c_sum_count[i]/count[i], no_c_count[i]/count[i])

def data2picture(option):
	sql_file = "{}.sql".format(option)
	tar_file = "../data/{}/{}.csv".format(option, option)
	# run_sql(sql_file, tar_file)
	data, rowname = read_file(tar_file)
	m_data = [[] for _ in range(10)]
	count = 0
	for key, value in data.items():
		count += 1
		if len(value) == 0: continue
		if count % 10 == 0:
			for i in range(10):
				try:
					m_data[i].append(int(value[i]))
				except Exception as e:
					print(e)
					print(i)
					print(value)
					return
	for i in range(1, 10):
		print(rowname[i])
		print(len(m_data[i]))
		draw_picture(m_data[i], m_data[0], option, rowname[i+1].split(".")[-1], rowname[1].split(".")[-1])
	# question_type(data)
	print("Finish!")
	# is_marked(data, -2)
	# is_marked(data, -3)
def is_marked(data, i):
	# 评论数目与是否标优的情况统计 i=-2
	# 评论数目与是否推荐的情况统计 i=-3
	mark_n, no_mark_n = 0, 0
	mark_c_count, no_mark_c_count = 0, 0
	mark_c_no, no_mark_c_no = 0, 0 # 0评论的比例
	for key, value in data.items():
		pmark = int(value[i])
		if pmark == 1:
			mark_n += 1
			mark_c_count += int(value[0])
			if int(value[0]) == 0: mark_c_no += 1
		elif pmark == 0:
			no_mark_n += 1
			no_mark_c_count += int(value[0])
			if int(value[0]) == 0: no_mark_c_no += 1
		else:
			pass
	print(mark_n, mark_c_count, mark_c_count/mark_n, mark_c_no, mark_c_no/mark_c_count)
	print(no_mark_n, no_mark_c_count, no_mark_c_count/no_mark_n, no_mark_c_no, no_mark_c_no/no_mark_c_count)



def caculate(data_dict, option):
	"""
	计算 均值、最值、方差、众数、中数
	:param data_dict:
	:return:
	"""
	data_ls = []
	most_dict = dict()
	max_num, min_num, sum_num, count = 0, 1e5, 0, 0
	valid_count = 0
	for key, value in data_dict.items():
		num = int(value[0])
		if num == 0: count+=1;continue
		max_num = num if num>max_num else max_num
		min_num = num if num<min_num else min_num
		count += 1
		valid_count += 1
		sum_num += num
		data_ls.append([key, num])
		if num in most_dict:
			most_dict[num][0] += 1
		else:
			most_dict[num] = [1, key]
	data_ls = sorted(data_ls, key=lambda x:x[1])
	print(valid_count)
	print("中数:", data_ls[int(len(data_ls)/2)])
	max_index = max(most_dict, key=most_dict.get)
	print("众数:", most_dict[max_index], max_index) #次数 id 数目
	print("1-15的各个数目:")
	[print(most_dict[item], most_dict[item][0]/valid_count) for item in range(1, 16)]
	ratio = 0 # 90%的评论对应的评论数目
	for i in range(1,50):
		ratio += most_dict[i][0]/valid_count
		if ratio > 0.9:
			print(ratio, i)
			break
	avg = sum_num/valid_count
	print("均值:", avg)
	print("最大值:", max_num, "最小值:", min_num)
	theta = 0
	for x in data_ls:
		theta += (x[1]-avg)**2
	print("方差：", theta/valid_count)
	with open("../data/{}/{}.valid.txt".format(option, option), "w") as f:
		f.write("{} \n".format(option))
		f.write("均值：{}  方差:{} \n".format(avg, theta))
		f.write("中数:{} \n".format(data_ls[int(len(data_ls)/2)]))
		f.write("最大值：{}  最小值: {} \n".format(max_num, min_num))
		f.write("众数:{} {} \n".format(most_dict[max_index], max_index))

def read_file(filepath):
	"""
	read csv file
	:return:
	"""
	data_dict = dict()
	rowname = []
	with open(filepath) as csvfile:
		pd_reader = csv.reader(csvfile, delimiter='\t', quoting=csv.QUOTE_NONE)
		for lidx, line in enumerate(pd_reader):
			if lidx == 0:
				rowname = line
				print(line)
				continue
			data_dict[line[0]] = line[1:]
	return data_dict, rowname

def run_sql(sql_file, tar_file):
    """
    python调用hive命令运行sql脚本
    :return:
    """
    print("run hive for {}".format(sql_file.split(".")[0]))
    output = os.popen("hive -f {} > {}".format(sql_file, tar_file))
    print(output.read())

def main():
	"""
	主函数
	:return:
	"""
	#参数 article // question // answer
	option = sys.argv[1]
	# run_sql("{}.sql".format(option), "../data/{}/{}.csv".format(option, option))
	# data_dict, _ = read_file("../data/{}/{}.csv".format(option, option))
	# caculate(data_dict, option)
	data2picture(option)

if __name__ == '__main__':
	main()

# 运行命令  python run.py article
